# -*- coding: utf-8 -*-
"""
Deduplicate gallery assets and prune unused legacy files.
"""
import os
import hashlib
import shutil

BASE_DIR = r"C:\Users\SURFACE\.gemini\antigravity\scratch\youth-ngo-website\nature-website-template"
PARENT_DIR = r"C:\Users\SURFACE\.gemini\antigravity\scratch\youth-ngo-website"

# 1. Remove old zip in parent dir that caused 38MB total
old_parent_zip = os.path.join(PARENT_DIR, "gnep-africa-work-package.zip")
if os.path.exists(old_parent_zip):
    os.remove(old_parent_zip)
    print(f"Removed {old_parent_zip}")

# 2. Find duplicate files in nature-website-template
hashes = {}
duplicates = [] # (dup_path, canonical_path)

for root, dirs, files in os.walk(BASE_DIR):
    for f in sorted(files):
        fp = os.path.join(root, f)
        # only check images in assets/real/gallery
        if "assets\\real\\gallery" in fp:
            with open(fp, "rb") as fh:
                h = hashlib.md5(fh.read()).hexdigest()
            if h in hashes:
                duplicates.append((fp, hashes[h]))
            else:
                hashes[h] = fp

print(f"Found {len(duplicates)} duplicate gallery images.")

# Update HTML references to use canonical path
html_files = [
    os.path.join(BASE_DIR, "gallery.html"),
    os.path.join(BASE_DIR, "index.html"),
    os.path.join(BASE_DIR, "events.html"),
    os.path.join(BASE_DIR, "about.html")
]

for dup_path, canonical_path in duplicates:
    rel_dup = os.path.relpath(dup_path, BASE_DIR).replace("\\", "/")
    rel_canonical = os.path.relpath(canonical_path, BASE_DIR).replace("\\", "/")
    
    for hf in html_files:
        if os.path.exists(hf):
            with open(hf, "r", encoding="utf-8") as f:
                content = f.read()
            if rel_dup in content:
                content = content.replace(rel_dup, rel_canonical)
                with open(hf, "w", encoding="utf-8") as f:
                    f.write(content)
                print(f"Replaced {rel_dup} -> {rel_canonical} in {os.path.basename(hf)}")
    
    # Delete the duplicate file
    if os.path.exists(dup_path):
        os.remove(dup_path)

print(f"Deleted {len(duplicates)} duplicate files.")

# 3. Remove unused 1.86 MB PNG (we use founder-mohammed-labaran-sani.webp)
founder_png = os.path.join(BASE_DIR, "assets", "real", "founder-mohammed-labaran-sani.png")
if os.path.exists(founder_png):
    os.remove(founder_png)
    print("Removed unused founder-mohammed-labaran-sani.png (1.86 MB)")

# 4. Remove unused legacy img/ directory (1.64 MB of old Environs template images)
img_dir = os.path.join(BASE_DIR, "img")
if os.path.exists(img_dir):
    shutil.rmtree(img_dir)
    print("Removed unused legacy img/ directory (1.64 MB)")

# 5. Measure new total size
new_total = sum(os.path.getsize(os.path.join(root, f)) for root, dirs, files in os.walk(BASE_DIR) for f in files)
print(f"New total uncompressed size: {new_total / (1024*1024):.2f} MB")
