import asyncio
from playwright.async_api import async_playwright

async def test_gallery():
    async with async_playwright() as p:
        browser = await p.chromium.launch(
            executable_path=r'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe',
            headless=True
        )
        page = await browser.new_page(viewport={'width': 1280, 'height': 800})
        await page.goto(r'file:///C:/Users/SURFACE/.gemini/antigravity/scratch/youth-ngo-website/nature-website-template/gallery.html')
        await page.wait_for_timeout(1000)
        
        art_dir = r'C:\Users\SURFACE\.gemini\antigravity\brain\88197918-f7d9-4207-b0c0-288c09f74bfd'
        
        # Scroll to load lazy images
        for y in range(0, 4000, 400):
            await page.evaluate(f'window.scrollTo(0, {y})')
            await page.wait_for_timeout(60)
        await page.evaluate('window.scrollTo(0, 0)')
        await page.wait_for_timeout(400)
        
        await page.screenshot(path=f'{art_dir}\\gallery-desktop-preview.png')
        await page.screenshot(path=f'{art_dir}\\gallery-desktop-full.png', full_page=True)

        # Mobile view
        mobile_page = await browser.new_page(viewport={'width': 375, 'height': 812})
        await mobile_page.goto(r'file:///C:/Users/SURFACE/.gemini/antigravity/scratch/youth-ngo-website/nature-website-template/gallery.html')
        await mobile_page.wait_for_timeout(1000)
        for y in range(0, 6000, 400):
            await mobile_page.evaluate(f'window.scrollTo(0, {y})')
            await mobile_page.wait_for_timeout(60)
        await mobile_page.evaluate('window.scrollTo(0, 0)')
        await mobile_page.wait_for_timeout(400)
        
        await mobile_page.screenshot(path=f'{art_dir}\\gallery-mobile-preview.png')

        await browser.close()
        print('Gallery screenshots captured successfully!')

asyncio.run(test_gallery())
