# -*- coding: utf-8 -*-
import os

BASE_DIR = r"C:\Users\SURFACE\.gemini\antigravity\scratch\youth-ngo-website\nature-website-template"
gallery_path = os.path.join(BASE_DIR, "gallery.html")

with open(gallery_path, "r", encoding="utf-8") as f:
    gallery_html = f.read()

new_gallery_items = """                    <!-- Featured 2026 CSO Workshop Announcement & Lead Facilitator -->
                    <div class="col-lg-4 col-md-6 gallery-item-col" data-category="workshops">
                        <article class="gallery-card spatial-tilt-card">
                            <div class="gallery-img-container">
                                <a href="assets/real/cso-workshop-policy-2026.webp" data-lightbox="gnep-gallery" data-title="Building Civil Society Capacity for Environmental Advocacy in Katsina — Official Announcement Graphic &amp; Keynote (Photo: GNEP / The Green Minds Space, 2026)">
                                    <img src="assets/real/cso-workshop-policy-2026.webp" alt="Building Civil Society Capacity for Environmental Advocacy in Katsina" class="gallery-img" loading="lazy" width="600" height="450">
                                    <div class="gallery-overlay">
                                        <div class="gallery-overlay-icon">
                                            <i class="fas fa-search-plus" aria-hidden="true"></i>
                                        </div>
                                        <span class="gallery-overlay-text">Expand Graphic</span>
                                    </div>
                                </a>
                                <span class="gallery-badge bg-success text-white">Workshop 2026</span>
                            </div>
                            <div class="gallery-info">
                                <div class="gallery-meta">
                                    <span class="text-success"><i class="fas fa-calendar-alt me-1" aria-hidden="true"></i>2026</span>
                                    <span><i class="fas fa-map-marker-alt me-1" aria-hidden="true"></i>Katsina State</span>
                                </div>
                                <h3 class="gallery-title">CSO Policy Advocacy &amp; Proposal Training Graphic</h3>
                                <p class="gallery-desc">Official release for the capacity workshop training 20 CSO leaders in policy briefs, competitive proposals, elevator pitches, and AI research tools.</p>
                                <div class="gallery-footer">
                                    <span class="gallery-credit">Credit: GNEP / The Green Minds Space</span>
                                    <a href="cso-policy-workshop.html" class="gallery-tag text-decoration-none">Read Story &rarr;</a>
                                </div>
                            </div>
                        </article>
                    </div>

                    <div class="col-lg-4 col-md-6 gallery-item-col" data-category="workshops">
                        <article class="gallery-card spatial-tilt-card">
                            <div class="gallery-img-container">
                                <a href="assets/real/cso-workshop-speaker-action.webp" data-lightbox="gnep-gallery" data-title="Mohammed Labaran Sani Facilitating the Policy &amp; Advocacy Workshop — Presenting the Policy to Action Framework in Katsina State (Photo: GNEP, 2026)">
                                    <img src="assets/real/cso-workshop-speaker-action.webp" alt="Mohammed Labaran Sani Facilitating Workshop" class="gallery-img" loading="lazy" width="600" height="450">
                                    <div class="gallery-overlay">
                                        <div class="gallery-overlay-icon">
                                            <i class="fas fa-search-plus" aria-hidden="true"></i>
                                        </div>
                                        <span class="gallery-overlay-text">Expand Photo</span>
                                    </div>
                                </a>
                                <span class="gallery-badge bg-primary text-white">Facilitation</span>
                            </div>
                            <div class="gallery-info">
                                <div class="gallery-meta">
                                    <span class="text-success"><i class="fas fa-calendar-alt me-1" aria-hidden="true"></i>2026</span>
                                    <span><i class="fas fa-chalkboard-teacher me-1" aria-hidden="true"></i>Leadership</span>
                                </div>
                                <h3 class="gallery-title">Mohammed Labaran Sani Facilitating Workshop</h3>
                                <p class="gallery-desc">Founder and Lead Mohammed Labaran Sani walking civil society representatives through evidence synthesis and policy brief structuring.</p>
                                <div class="gallery-footer">
                                    <span class="gallery-credit">Credit: GNEP</span>
                                    <a href="cso-policy-workshop.html" class="gallery-tag text-decoration-none">Read Story &rarr;</a>
                                </div>
                            </div>
                        </article>
                    </div>
"""

grid_needle = '<div class="row g-4" id="galleryGrid">'
idx = gallery_html.find(grid_needle)
if idx != -1 and "cso-workshop-policy-2026.webp" not in gallery_html:
    gallery_html = gallery_html[:idx + len(grid_needle)] + "\n" + new_gallery_items + gallery_html[idx + len(grid_needle):]
    with open(gallery_path, "w", encoding="utf-8") as f:
        f.write(gallery_html)
    print("Inserted new workshop items into gallery.html")
else:
    print("Already inserted or grid needle not found")
