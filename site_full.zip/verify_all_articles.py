import asyncio
from playwright.async_api import async_playwright
import os

ARTIFACT_DIR = r"C:\Users\SURFACE\.gemini\antigravity\brain\88197918-f7d9-4207-b0c0-288c09f74bfd"
EDGE_PATH = r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"

async def main():
    async with async_playwright() as p:
        browser = await p.chromium.launch(
            executable_path=EDGE_PATH,
            headless=True
        )
        context = await browser.new_context(viewport={'width': 1280, 'height': 850})
        page = await context.new_page()

        # 1. Tree Planting Article
        print("Navigating to tree-planting-150-seedlings.html...")
        await page.goto("http://localhost:8000/tree-planting-150-seedlings.html", wait_until="networkidle")
        await page.wait_for_timeout(1000)
        await page.screenshot(path=os.path.join(ARTIFACT_DIR, "article-tree-planting.png"))
        print("Captured article-tree-planting.png")

        # 2. Communicating Environmental Issues Article
        print("Navigating to communicating-environmental-issues.html...")
        await page.goto("http://localhost:8000/communicating-environmental-issues.html", wait_until="networkidle")
        await page.wait_for_timeout(1000)
        await page.screenshot(path=os.path.join(ARTIFACT_DIR, "article-storytelling.png"))
        print("Captured article-storytelling.png")

        # 3. Heat Emergency Policy Brief
        print("Navigating to nigeria-heat-emergency-policy-brief.html...")
        await page.goto("http://localhost:8000/nigeria-heat-emergency-policy-brief.html", wait_until="networkidle")
        await page.wait_for_timeout(1000)
        await page.screenshot(path=os.path.join(ARTIFACT_DIR, "article-heat-policy-brief.png"))
        print("Captured article-heat-policy-brief.png")

        # 4. Events page showing all clickable article cards
        print("Navigating to events.html...")
        await page.goto("http://localhost:8000/events.html", wait_until="networkidle")
        await page.wait_for_timeout(1000)
        await page.screenshot(path=os.path.join(ARTIFACT_DIR, "events-all-articles-linked.png"))
        print("Captured events-all-articles-linked.png")

        await browser.close()
        print("All article screenshots captured successfully!")

asyncio.run(main())
