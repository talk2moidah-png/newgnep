# -*- coding: utf-8 -*-
"""
Extract media from docx files in Downloads and optimize them for the website.
"""
import os
import zipfile
import shutil
from PIL import Image

DOWNLOADS = r"C:\Users\SURFACE\Downloads"
DEST_DIR = r"C:\Users\SURFACE\.gemini\antigravity\scratch\youth-ngo-website\nature-website-template\assets\real"

# 1. Copy & optimize Nigeria's Super El Nino Heat Crisis graphic
heat_png = os.path.join(DOWNLOADS, "Nigeria's Super El Niño Heat Crisis.png")
if os.path.exists(heat_png):
    im_heat = Image.open(heat_png)
    im_heat.save(os.path.join(DEST_DIR, "nigeria-heat-emergency-crisis.webp"), "WEBP", quality=90)
    print("Saved nigeria-heat-emergency-crisis.webp")

# 2. Extract media from Communicating Environmental Issues.docx
comm_docx = os.path.join(DOWNLOADS, "Communicating Environmental Issues.docx")
if os.path.exists(comm_docx):
    with zipfile.ZipFile(comm_docx) as z:
        for i, n in enumerate([m for m in z.namelist() if "media" in m]):
            data = z.read(n)
            out_name = f"storytelling-comm-0{i+1}.webp"
            with open("temp_img.png", "wb") as f:
                f.write(data)
            im = Image.open("temp_img.png")
            im.save(os.path.join(DEST_DIR, out_name), "WEBP", quality=90)
            print(f"Saved {out_name} ({im.size})")
    if os.path.exists("temp_img.png"):
        os.remove("temp_img.png")

# 3. Extract media from Nigeria_Heat_Emergency_Policy_Brief.docx
heat_docx = os.path.join(DOWNLOADS, "Nigeria_Heat_Emergency_Policy_Brief.docx")
if os.path.exists(heat_docx):
    with zipfile.ZipFile(heat_docx) as z:
        for i, n in enumerate([m for m in z.namelist() if "media" in m][:3]):
            data = z.read(n)
            out_name = f"heat-policy-brief-fig-0{i+1}.webp"
            with open("temp_img2.png", "wb") as f:
                f.write(data)
            im = Image.open("temp_img2.png")
            im.save(os.path.join(DEST_DIR, out_name), "WEBP", quality=90)
            print(f"Saved {out_name} ({im.size})")
    if os.path.exists("temp_img2.png"):
        os.remove("temp_img2.png")

print("All article assets extracted successfully!")
