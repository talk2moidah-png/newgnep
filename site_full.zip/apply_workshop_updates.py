# -*- coding: utf-8 -*-
"""
Applies the CSO Workshop announcement, graphic, and full editorial integration across:
- index.html
- events.html
- founder.html
- gallery.html
"""
import os
import re

BASE_DIR = r"C:\Users\SURFACE\.gemini\antigravity\scratch\youth-ngo-website\nature-website-template"

# 1. Update index.html
index_path = os.path.join(BASE_DIR, "index.html")
with open(index_path, "r", encoding="utf-8") as f:
    index_html = f.read()

# Update Update Card 1
old_card1_start = index_html.find("<!-- Update Card 1: CSO Workshop -->")
if old_card1_start != -1:
    old_card1_end = index_html.find("<!-- Update Card 2: Tree Planting with AYINET -->", old_card1_start)
    if old_card1_end != -1:
        new_card1 = """<!-- Update Card 1: CSO Workshop (Official Press Release) -->
                    <div class="col-lg-4 col-md-6">
                        <article class="update-card spatial-tilt-card">
                            <div class="update-img-wrap">
                                <a href="cso-policy-workshop.html">
                                    <img src="assets/real/cso-workshop-policy-2026.webp" alt="GNEP Trains 20 Civil Society Representatives in Katsina" loading="lazy" width="600" height="350" style="object-fit: cover; width: 100%; aspect-ratio: 16/10;">
                                </a>
                            </div>
                            <div class="update-credit">Photo: GNEP / The Green Minds Space</div>
                            <div class="update-body">
                                <div class="update-meta">
                                    <span class="update-type-tag">Capacity Workshop</span>
                                    <span class="update-date"><i class="far fa-calendar-alt me-1" aria-hidden="true"></i> 2026</span>
                                </div>
                                <h3 class="update-headline"><a href="cso-policy-workshop.html" class="text-dark text-decoration-none">GNEP Trains 20 Civil Society Leaders in Policy Brief Writing &amp; Pitching</a></h3>
                                <p class="update-excerpt">
                                    A capacity-building workshop in Katsina State with The Green Minds Space equipping 20 leaders with skills in policy briefs, competitive funding proposals, persuasive communication, and responsible AI tools.
                                </p>
                                <a href="cso-policy-workshop.html" class="update-link">Read full story &amp; outcomes <i class="fas fa-arrow-right ms-1" aria-hidden="true"></i></a>
                            </div>
                        </article>
                    </div>\n\n                    """
        index_html = index_html[:old_card1_start] + new_card1 + index_html[old_card1_end:]
        print("Updated Update Card 1 in index.html")

# In index.html, embed speaker action image in founderBioModal under Chapter 4
speaker_img_html = """
                                <div class="my-3 rounded-3 overflow-hidden border shadow-sm">
                                    <img src="assets/real/cso-workshop-speaker-action.webp" alt="Mohammed Labaran Sani facilitating CSO workshop in Katsina" class="img-fluid w-100" style="object-fit: cover;">
                                    <div class="p-2 bg-light small text-muted text-center">
                                        <i class="fas fa-chalkboard-teacher text-success me-1"></i> Mohammed Labaran Sani facilitating the 2026 Civil Society Policy &amp; Advocacy Workshop in Katsina State.
                                    </div>
                                </div>
"""
if "cso-workshop-speaker-action.webp" not in index_html:
    target_needle = "Co-hosted with The Green Minds Space for 20 civil society representatives in Katsina State"
    t_idx = index_html.find(target_needle)
    if t_idx != -1:
        # find closing li
        li_close = index_html.find("</li>", t_idx)
        if li_close != -1:
            index_html = index_html[:li_close+5] + speaker_img_html + index_html[li_close+5:]
            print("Embedded speaker action image into founderBioModal in index.html")

with open(index_path, "w", encoding="utf-8") as f:
    f.write(index_html)


# 2. Update events.html
events_path = os.path.join(BASE_DIR, "events.html")
with open(events_path, "r", encoding="utf-8") as f:
    events_html = f.read()

events_card1_start = events_html.find("<!-- Card 1: Policy Brief Workshop -->")
if events_card1_start != -1:
    events_card1_end = events_html.find("<!-- Card 2: Tree Planting -->", events_card1_start)
    if events_card1_end != -1:
        new_events_card1 = """<!-- Card 1: Policy Brief Workshop (Official Press Release) -->
                    <div class="col-lg-4 col-md-6 activity-item" data-category="workshop">
                        <article class="gnep-activity-card spatial-tilt-card">
                            <a href="cso-policy-workshop.html">
                                <img src="assets/real/cso-workshop-policy-2026.webp"
                                     alt="GNEP Trains 20 Civil Society Representatives in Policy Brief Writing, Katsina State"
                                     class="gnep-activity-img" loading="lazy" style="object-fit: cover; height: 230px;">
                            </a>
                            <div class="gnep-activity-body">
                                <div class="gnep-activity-meta">
                                    <span class="gnep-activity-tag tag-workshop">Workshop</span>
                                    <span class="gnep-activity-date"><i class="fas fa-calendar me-1" aria-hidden="true"></i>2026</span>
                                </div>
                                <h3 class="gnep-activity-title"><a href="cso-policy-workshop.html" class="text-dark text-decoration-none">Policy Brief, Proposal Development &amp; Elevator Pitch Workshop</a></h3>
                                <p class="gnep-activity-excerpt">A capacity-building workshop for 20 civil society representatives in Katsina State. Topics included writing effective policy briefs and proposals, delivering elevator pitches, and using AI tools for research and productivity. Co-hosted with The Green Minds Space.</p>
                                <ul class="list-unstyled small text-muted mt-2 mb-3">
                                    <li><i class="fas fa-users me-2 text-success" aria-hidden="true"></i><strong>20</strong> civil society representatives</li>
                                    <li><i class="fas fa-map-marker-alt me-2 text-success" aria-hidden="true"></i>Katsina State, Nigeria &bull; 2026</li>
                                    <li><i class="fas fa-handshake me-2 text-success" aria-hidden="true"></i>Co-hosted with The Green Minds Space</li>
                                </ul>
                                <a href="cso-policy-workshop.html" class="btn btn-sm btn-outline-success w-100">
                                    <i class="fas fa-newspaper me-1"></i> Read Full Press Release &amp; Report
                                </a>
                                <div class="gnep-activity-footer">
                                    <span class="gnep-photo-credit">Photo credit: GNEP / The Green Minds Space</span>
                                </div>
                            </div>
                        </article>
                    </div>\n\n                    """
        events_html = events_html[:events_card1_start] + new_events_card1 + events_html[events_card1_end:]
        print("Updated Card 1 in events.html")

with open(events_path, "w", encoding="utf-8") as f:
    f.write(events_html)


# 3. Update founder.html with speaker action photo in Chapter 4
founder_path = os.path.join(BASE_DIR, "founder.html")
with open(founder_path, "r", encoding="utf-8") as f:
    founder_html = f.read()

if "cso-workshop-speaker-action.webp" not in founder_html:
    f_needle = "<strong>20 Civil Society Representatives Trained:</strong> Workshop on policy brief writing"
    f_idx = founder_html.find(f_needle)
    if f_idx != -1:
        f_li_close = founder_html.find("</li>", f_idx)
        if f_li_close != -1:
            founder_html = founder_html[:f_li_close+5] + speaker_img_html + founder_html[f_li_close+5:]
            print("Embedded speaker action image into founder.html")

with open(founder_path, "w", encoding="utf-8") as f:
    f.write(founder_html)


# 4. Update about.html modal if present
about_path = os.path.join(BASE_DIR, "about.html")
with open(about_path, "r", encoding="utf-8") as f:
    about_html = f.read()

if "cso-workshop-speaker-action.webp" not in about_html:
    a_needle = "Co-hosted with The Green Minds Space for 20 civil society representatives in Katsina State"
    a_idx = about_html.find(a_needle)
    if a_idx != -1:
        a_li_close = about_html.find("</li>", a_idx)
        if a_li_close != -1:
            about_html = about_html[:a_li_close+5] + speaker_img_html + about_html[a_li_close+5:]
            print("Embedded speaker action image into about.html modal")

with open(about_path, "w", encoding="utf-8") as f:
    f.write(about_html)

print("All site files updated with CSO workshop integration successfully!")
