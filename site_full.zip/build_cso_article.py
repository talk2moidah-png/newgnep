# -*- coding: utf-8 -*-
"""
Generate the dedicated editorial field story page: cso-policy-workshop.html
"""
import os

BASE_DIR = r"C:\Users\SURFACE\.gemini\antigravity\scratch\youth-ngo-website\nature-website-template"

HTML_CONTENT = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>GNEP Trains 20 Civil Society Representatives in Katsina | GNEP Africa</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="GNEP workshop, civil society, policy brief writing, proposal development, Katsina State, The Green Minds Space, AI for research" name="keywords">
    <meta content="GNEP and The Green Minds Space trained 20 civil society representatives in Katsina State on policy briefs, funding proposals, pitch communication, and responsible AI tools." name="description">

    <!-- Open Graph -->
    <meta property="og:title" content="GNEP Trains 20 Civil Society Representatives in Policy Brief Writing &amp; Pitch Communication">
    <meta property="og:description" content="Capacity-building initiative equipping grassroots leaders in Katsina State with skills for evidence-informed policy engagement and competitive funding proposals.">
    <meta property="og:image" content="assets/real/cso-workshop-policy-2026.webp">
    <meta property="og:type" content="article">

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Newsreader:ital,opsz,wght@0,6..72,400;0,6..72,500;0,6..72,600;1,6..72,400&family=Plus+Jakarta+Sans:wght@500;600;700;800&display=swap" rel="stylesheet"> 

    <!-- Icon Font Stylesheet -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css"/>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/lightbox/css/lightbox.min.css" rel="stylesheet">

    <!-- Customized Bootstrap & Site Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/gnep.css" rel="stylesheet">

    <style>
        .article-hero {
            position: relative;
            background: linear-gradient(135deg, #0B2516 0%, #153E26 60%, #1A4D2E 100%);
            padding-top: 140px;
            padding-bottom: 70px;
            color: #ffffff;
            overflow: hidden;
        }
        .article-hero::before {
            content: '';
            position: absolute;
            inset: 0;
            background: radial-gradient(circle at 80% 20%, rgba(16, 185, 129, 0.2) 0%, transparent 60%);
            pointer-events: none;
        }
        .article-meta-badge {
            display: inline-flex;
            align-items: center;
            gap: 0.4rem;
            background: rgba(255, 255, 255, 0.12);
            color: #E2E8F0;
            font-size: 0.82rem;
            font-weight: 600;
            padding: 0.35rem 0.85rem;
            border-radius: 50px;
            border: 1px solid rgba(255, 255, 255, 0.2);
        }
        .article-body-content {
            font-size: 1.05rem;
            line-height: 1.8;
            color: #2D3748;
        }
        .article-body-content h2, .article-body-content h3 {
            font-family: 'Plus Jakarta Sans', sans-serif;
            font-weight: 700;
            color: #0B2516;
            margin-top: 2.5rem;
            margin-bottom: 1rem;
        }
        .article-body-content p {
            margin-bottom: 1.35rem;
        }
        .article-quote-box {
            font-family: 'Newsreader', Georgia, serif;
            font-style: italic;
            font-size: 1.25rem;
            line-height: 1.6;
            color: #0B2516;
            border-left: 4px solid #10B981;
            padding: 1.5rem 1.75rem;
            background: #F0FDF4;
            border-radius: 0 10px 10px 0;
            margin: 2.25rem 0;
        }
        .article-sidebar-box {
            background: #FAFCF9;
            border-radius: 12px;
            padding: 1.75rem;
            border: 1px solid #E2E8F0;
            margin-bottom: 2rem;
        }
        .article-sidebar-title {
            font-size: 0.8rem;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            font-weight: 700;
            color: #718096;
            margin-bottom: 1rem;
        }
        .article-key-fact {
            display: flex;
            align-items: flex-start;
            gap: 0.75rem;
            margin-bottom: 1rem;
            font-size: 0.92rem;
        }
        .article-key-fact:last-child {
            margin-bottom: 0;
        }
        .article-key-fact i {
            color: #15803D;
            margin-top: 4px;
            font-size: 1rem;
            flex-shrink: 0;
        }
    </style>
</head>

<body>
    <!-- Skip to main content -->
    <a class="skip-to-content" href="#main-content">Skip to main content</a>

    <!-- Topbar & Navigation -->
    <header class="fixed-top">
        <aside class="gnep-topbar d-none d-md-block" aria-label="Quick Links">
            <div class="container d-flex justify-content-between align-items-center">
                <div class="d-flex align-items-center">
                    <a href="events.html"><i class="fas fa-file-alt me-1" aria-hidden="true"></i> Research and Insights</a>
                    <span class="topbar-divider">|</span>
                    <a href="contact.html"><i class="fas fa-envelope me-1" aria-hidden="true"></i> Contact</a>
                    <span class="topbar-divider">|</span>
                    <a href="https://www.linkedin.com/company/global-nature-environmental-partnership/" target="_blank" rel="noopener noreferrer"><i class="fab fa-linkedin me-1" aria-hidden="true"></i> LinkedIn</a>
                </div>
                <div class="d-flex align-items-center text-white-50 small">
                    <span class="me-3"><i class="fas fa-map-marker-alt text-white me-1" aria-hidden="true"></i> Katsina State, Nigeria</span>
                    <a href="mailto:gnep.partnership@gmail.com" class="text-white"><i class="fas fa-paper-plane me-1" aria-hidden="true"></i> gnep.partnership@gmail.com</a>
                </div>
            </div>
        </aside>

        <nav class="navbar navbar-expand-lg gnep-navbar" aria-label="Main Navigation">
            <div class="container">
                <a href="index.html" class="gnep-brand-wrap" aria-label="GNEP Africa Homepage">
                    <img src="assets/real/gnep-logo.webp" alt="GNEP Logo" class="gnep-brand-logo" width="160" height="48">
                    <div class="gnep-brand-text d-none d-sm-block">
                        <span class="gnep-brand-title">GNEP Africa</span>
                        <span class="gnep-brand-sub">Global Nature &amp; Environmental Partnership</span>
                    </div>
                </a>
                <button class="navbar-toggler py-2 px-3" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation menu">
                    <span class="fa fa-bars text-dark fs-5"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarCollapse">
                    <ul class="navbar-nav ms-auto align-items-lg-center">
                        <li class="nav-item"><a href="about.html" class="nav-link">About GNEP</a></li>
                        <li class="nav-item dropdown">
                            <a href="index.html#focus-areas" class="nav-link dropdown-toggle" id="workDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">Our Work</a>
                            <ul class="dropdown-menu" aria-labelledby="workDropdown">
                                <li><a class="dropdown-item" href="index.html#focus-areas">1. Climate Action &amp; Resilience</a></li>
                                <li><a class="dropdown-item" href="index.html#focus-areas">2. Nature &amp; Ecosystem Restoration</a></li>
                                <li><a class="dropdown-item" href="index.html#focus-areas">3. Environmental Governance &amp; Policy</a></li>
                                <li><a class="dropdown-item" href="index.html#focus-areas">4. Youth Leadership &amp; Participation</a></li>
                                <li><a class="dropdown-item" href="index.html#focus-areas">5. WEFE Nexus <span class="badge bg-secondary ms-1 text-dark">Strategic Direction</span></a></li>
                                <li><a class="dropdown-item" href="index.html#focus-areas">6. Research &amp; Capacity Development</a></li>
                            </ul>
                        </li>
                        <li class="nav-item dropdown">
                            <a href="events.html" class="nav-link dropdown-toggle active" id="updatesDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false" aria-current="page">Updates</a>
                            <ul class="dropdown-menu" aria-labelledby="updatesDropdown">
                                <li><a class="dropdown-item" href="events.html">Events &amp; Workshops</a></li>
                                <li><a class="dropdown-item" href="events.html">Research &amp; Insights</a></li>
                                <li><a class="dropdown-item" href="gallery.html">Field Gallery</a></li>
                            </ul>
                        </li>
                        <li class="nav-item"><a href="contact.html" class="nav-link">Get Involved</a></li>
                    </ul>
                    <div class="d-flex align-items-center ms-lg-3 mt-3 mt-lg-0">
                        <a href="contact.html" class="btn-partner-nav text-center w-100 w-lg-auto">Partner With Us</a>
                    </div>
                </div>
            </div>
        </nav>
    </header>

    <main id="main-content">
        <!-- Article Hero Header -->
        <section class="article-hero" aria-label="Article Header">
            <div class="container">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb" style="background: none; padding: 0; margin-bottom: 1.5rem;">
                        <li class="breadcrumb-item"><a href="index.html" class="text-white-50 text-decoration-none">Home</a></li>
                        <li class="breadcrumb-item"><a href="events.html" class="text-white-50 text-decoration-none">Updates &amp; Field Work</a></li>
                        <li class="breadcrumb-item active text-white" aria-current="page">Field Story</li>
                    </ol>
                </nav>

                <div class="d-flex flex-wrap gap-2 mb-3">
                    <span class="article-meta-badge"><i class="fas fa-calendar-alt text-success" aria-hidden="true"></i> 2026</span>
                    <span class="article-meta-badge"><i class="fas fa-map-marker-alt text-success" aria-hidden="true"></i> Katsina State, Nigeria</span>
                    <span class="article-meta-badge"><i class="fas fa-users text-success" aria-hidden="true"></i> 20 Civil Society Leaders</span>
                    <span class="article-meta-badge"><i class="fas fa-handshake text-success" aria-hidden="true"></i> Partner: The Green Minds Space</span>
                </div>

                <h1 class="display-5 fw-bold text-white mb-3" style="max-width: 900px; line-height: 1.25;">
                    GNEP Trains 20 Civil Society Representatives in Policy Brief Writing, Proposal Development and Pitch Communication
                </h1>
                
                <p class="lead text-white-50 mb-0" style="max-width: 800px; font-size: 1.2rem;">
                    Strengthening research, communication, proposal competitiveness, and evidence-based policy engagement for sustainable environmental governance in northern Nigeria.
                </p>
            </div>
        </section>

        <!-- Main Content -->
        <section class="py-5 bg-white" aria-label="Article Body">
            <div class="container">
                <div class="row g-5">
                    <!-- Left Editorial Column -->
                    <div class="col-lg-8">
                        <!-- Featured Announcement Graphic & Photo -->
                        <div class="mb-4 rounded-3 overflow-hidden shadow-sm border">
                            <img src="assets/real/cso-workshop-policy-2026.webp" alt="GNEP Civil Society Capacity Building Workshop in Katsina State" class="img-fluid w-100" style="object-fit: contain;">
                            <div class="p-3 bg-light border-top small text-muted d-flex justify-content-between align-items-center">
                                <span><i class="fas fa-camera text-success me-1"></i> Mohammed Labaran Sani presenting on policy frameworks at the workshop</span>
                                <span>Credit: GNEP &bull; Katsina State</span>
                            </div>
                        </div>

                        <div class="article-body-content">
                            <p class="lead text-dark fw-normal" style="font-size: 1.15rem; line-height: 1.8;">
                                The Global Nature and Environmental Partnership (GNEP), in collaboration with The Green Minds Space, organised a capacity-building workshop in Katsina State to strengthen the policy communication, proposal development, and advocacy skills of civil society representatives.
                            </p>

                            <p>
                                The workshop brought together 20 civil society representatives for practical learning on policy brief writing, competitive funding proposal development, persuasive communication, and the use of artificial intelligence (AI) tools to support research and project development.
                            </p>

                            <div class="article-quote-box">
                                &ldquo;Translating community needs and research findings into compelling policy recommendations and fundable projects requires specialised analytical and communication skills.&rdquo;
                            </div>

                            <h2>Strengthening Civil Society Capacity</h2>
                            <p>
                                Civil society organisations play an important role in connecting communities with policymakers, advocating for improved public services, and promoting inclusive development. However, translating community needs and research findings into compelling policy recommendations and fundable projects requires specialised skills.
                            </p>
                            <p>
                                The workshop was designed to address this capacity gap by equipping participants with practical tools to develop clear policy arguments, formulate structured project proposals, and communicate their ideas effectively to decision-makers and potential funding partners.
                            </p>
                            <p>
                                Through guided sessions and practical exercises, participants explored how to identify policy problems, organise supporting evidence, develop actionable recommendations, and present project ideas in ways that respond to institutional priorities and community needs.
                            </p>

                            <h2>From Policy Analysis to Practical Recommendations</h2>
                            <p>
                                A central component of the workshop focused on policy brief writing. Participants were introduced to the importance of concise, evidence-based policy communication and the need to present complex issues in accessible language.
                            </p>
                            <p>
                                The sessions emphasised the relationship between problem identification, evidence, policy options, and actionable recommendations. These skills are relevant to civil society organisations seeking to contribute meaningfully to public policy discussions and strengthen accountability.
                            </p>

                            <!-- In-text photo break -->
                            <div class="my-4 rounded-3 overflow-hidden shadow-sm border">
                                <img src="assets/real/cso-workshop-group.webp" alt="Civil Society Participants at the GNEP Policy Brief Workshop" class="img-fluid w-100" style="object-fit: cover;">
                                <div class="p-2 bg-light border-top small text-muted text-center">
                                    Participants and facilitators gathered at the capacity-building session in Katsina State.
                                </div>
                            </div>

                            <h2>Developing Competitive Project Proposals</h2>
                            <p>
                                The workshop also addressed project proposal development, with attention to the process of translating identified problems into structured interventions.
                            </p>
                            <p>
                                Participants explored key elements of proposal writing, including defining project objectives, identifying target beneficiaries, outlining activities, articulating expected results, and presenting project ideas clearly to potential funders.
                            </p>
                            <p>
                                Strengthening these skills can help civil society organisations communicate their priorities more effectively, identify appropriate funding opportunities, and develop projects that respond to the needs of the communities they serve.
                            </p>

                            <h2>Communicating Ideas with Confidence</h2>
                            <p>
                                Effective communication was another important element of the workshop. Participants explored how to present project ideas concisely, explain the significance of proposed interventions, and communicate their value to different audiences.
                            </p>
                            <p>
                                Pitch communication is particularly useful when engaging potential partners, presenting proposals, participating in funding competitions, and advocating for institutional support. The workshop encouraged participants to connect the problem they seek to address with the proposed response and its intended results.
                            </p>

                            <h2>Exploring AI for Research and Project Development</h2>
                            <p>
                                The programme introduced the application of AI tools to research and proposal development. Participants considered how these tools can support information organisation, preliminary research, drafting, and productivity.
                            </p>
                            <p>
                                The emphasis was on using technology as a support for professional work while retaining human judgement, source verification, contextual understanding, and responsibility for the final output. These considerations are particularly important when developing evidence-based policy documents and funding applications.
                            </p>

                            <h2>Building Stronger Civil Society Organisations</h2>
                            <p>
                                Through this initiative, GNEP continued its work at the intersection of research, policy engagement, youth participation, and institutional capacity development. The workshop reflected the organisation's commitment to helping civil society actors strengthen their ability to communicate evidence, develop practical interventions, and participate in policy processes.
                            </p>
                            <p>
                                The participation of 20 civil society representatives provided a foundation for further learning and professional engagement. Sustained application of the skills gained, alongside continued access to mentorship, research resources, and partnership opportunities, will be important for translating training into improved organisational practice.
                            </p>

                            <h2>Looking Ahead</h2>
                            <p>
                                GNEP recognises that effective environmental and development action depends partly on the capacity of institutions and community organisations to articulate problems, develop credible solutions, and engage decision-makers.
                            </p>
                            <p>
                                Through future training, research activities, and institutional partnerships, GNEP aims to continue supporting the development of practical skills that enable civil society organisations to contribute to more informed policymaking and locally relevant development initiatives.
                            </p>

                            <hr class="my-5">

                            <!-- Author & Organization Signature -->
                            <div class="p-4 bg-light rounded-3 border-start border-4 border-success">
                                <h3 class="h6 fw-bold text-dark mb-2">About GNEP</h3>
                                <p class="small text-muted mb-2">
                                    The Global Nature and Environmental Partnership (GNEP) is a youth-led environmental initiative based in Katsina State, Nigeria. Its work focuses on climate action, environmental sustainability, youth engagement, policy advocacy, nature restoration, and capacity development. GNEP works to connect people, policy, and practical solutions in support of more resilient communities.
                                </p>
                                <p class="small text-muted mb-0">
                                    <strong>Workshop Partners:</strong> Global Nature and Environmental Partnership (GNEP) and The Green Minds Space.
                                </p>
                            </div>

                            <div class="mt-4 d-flex flex-wrap gap-3">
                                <a href="contact.html" class="btn btn-success"><i class="fas fa-handshake me-2"></i>Partner With Us</a>
                                <a href="events.html" class="btn btn-outline-dark"><i class="fas fa-arrow-left me-2"></i>Back to All Updates</a>
                                <a href="gallery.html" class="btn btn-outline-success"><i class="fas fa-images me-2"></i>View in Gallery</a>
                            </div>
                        </div>
                    </div>

                    <!-- Right Sticky Sidebar -->
                    <div class="col-lg-4">
                        <div class="article-sidebar-box">
                            <div class="article-sidebar-title">Workshop Key Facts</div>
                            
                            <div class="article-key-fact">
                                <i class="fas fa-calendar-alt" aria-hidden="true"></i>
                                <div><strong>Year:</strong><br><span class="text-muted small">2026</span></div>
                            </div>
                            <div class="article-key-fact">
                                <i class="fas fa-map-marker-alt" aria-hidden="true"></i>
                                <div><strong>Location:</strong><br><span class="text-muted small">Katsina State, Nigeria</span></div>
                            </div>
                            <div class="article-key-fact">
                                <i class="fas fa-users" aria-hidden="true"></i>
                                <div><strong>Participants:</strong><br><span class="text-muted small">20 Civil Society Representatives</span></div>
                            </div>
                            <div class="article-key-fact">
                                <i class="fas fa-handshake" aria-hidden="true"></i>
                                <div><strong>Conveners:</strong><br><span class="text-muted small">GNEP &amp; The Green Minds Space</span></div>
                            </div>
                            <div class="article-key-fact">
                                <i class="fas fa-chalkboard-teacher" aria-hidden="true"></i>
                                <div><strong>Lead Facilitator:</strong><br><span class="text-muted small">Mohammed Labaran Sani (Founder, GNEP)</span></div>
                            </div>
                            <div class="article-key-fact">
                                <i class="fas fa-robot" aria-hidden="true"></i>
                                <div><strong>Key Modules:</strong><br><span class="text-muted small">Policy briefs, funding proposals, elevator pitches, ethical AI tools</span></div>
                            </div>
                        </div>

                        <!-- Founder Bio Link Box -->
                        <div class="article-sidebar-box text-center">
                            <img src="assets/real/founder-mohammed-labaran-sani.webp" alt="Mohammed Labaran Sani" class="rounded-circle border border-2 border-success mb-2" width="70" height="70" style="object-fit: cover;">
                            <h4 class="h6 fw-bold text-dark mb-1">Mohammed Labaran Sani</h4>
                            <p class="small text-muted mb-2">Founder &amp; Project Lead, GNEP Africa</p>
                            <a href="founder.html" class="btn btn-sm btn-outline-success rounded-pill px-3">
                                <i class="fas fa-user-circle me-1" aria-hidden="true"></i> View Founder Profile
                            </a>
                        </div>

                        <!-- Related Activities Box -->
                        <div class="article-sidebar-box">
                            <div class="article-sidebar-title">Related Field Activities</div>
                            <ul class="list-unstyled small mb-0">
                                <li class="mb-3">
                                    <a href="events.html" class="text-decoration-none fw-bold text-dark d-block">
                                        <i class="fas fa-seedling text-success me-1"></i> 150 Economic Tree Seedlings Planted
                                    </a>
                                    <span class="text-muted" style="font-size: 0.8rem;">Joint drive with AYINET across Katsina State</span>
                                </li>
                                <li class="mb-3">
                                    <a href="events.html" class="text-decoration-none fw-bold text-dark d-block">
                                        <i class="fas fa-building text-success me-1"></i> SUBEB &amp; UNICEF Workshop
                                    </a>
                                    <span class="text-muted" style="font-size: 0.8rem;">Institutional climate education participation</span>
                                </li>
                                <li>
                                    <a href="events.html" class="text-decoration-none fw-bold text-dark d-block">
                                        <i class="fas fa-school text-success me-1"></i> Climate Clubs in Schools
                                    </a>
                                    <span class="text-muted" style="font-size: 0.8rem;">Active student environmental networks</span>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>

    <!-- Standard GNEP Footer -->
    <footer class="gnep-footer" id="contact" aria-label="Footer and Contact Information">
        <div class="container">
            <div class="row g-4">
                <div class="col-lg-4 col-md-6">
                    <div class="d-flex align-items-center mb-3">
                        <img src="assets/real/gnep-logo.webp" alt="GNEP Logo" class="bg-white p-1 rounded" width="130" height="40" style="object-fit: contain;">
                    </div>
                    <p class="small text-light-50 mb-3" style="color: #BFD3C7;">
                        Global Nature and Environmental Partnership (GNEP Africa) is a youth-led initiative connecting climate research, policy, and education with practical community action across Africa.
                    </p>
                    <div class="small" style="color: #9EBAAB;">
                        <div><strong>Founded:</strong> 2025</div>
                        <div><strong>Base:</strong> Katsina State, Nigeria &bull; <strong>Outlook:</strong> Africa</div>
                    </div>
                    <div class="gnep-footer-approach mt-3">
                        <strong>Our Approach:</strong> We are committed to evidence-informed action, strictly verified data reporting, and transparently crediting all community and institutional partners.
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <h4>Our Work</h4>
                    <ul class="footer-link-list">
                        <li><a href="index.html#focus-areas"><i class="fas fa-angle-right me-2 text-success" aria-hidden="true"></i>Climate Action &amp; Resilience</a></li>
                        <li><a href="index.html#focus-areas"><i class="fas fa-angle-right me-2 text-success" aria-hidden="true"></i>Nature &amp; Ecosystem Restoration</a></li>
                        <li><a href="index.html#focus-areas"><i class="fas fa-angle-right me-2 text-success" aria-hidden="true"></i>Environmental Governance &amp; Policy</a></li>
                        <li><a href="index.html#focus-areas"><i class="fas fa-angle-right me-2 text-success" aria-hidden="true"></i>Youth Leadership &amp; Participation</a></li>
                        <li><a href="index.html#focus-areas"><i class="fas fa-angle-right me-2 text-success" aria-hidden="true"></i>WEFE Nexus (Strategic Direction)</a></li>
                        <li><a href="index.html#focus-areas"><i class="fas fa-angle-right me-2 text-success" aria-hidden="true"></i>Research &amp; Capacity Development</a></li>
                    </ul>
                </div>
                <div class="col-lg-2 col-md-6">
                    <h4>Get Involved</h4>
                    <ul class="footer-link-list">
                        <li><a href="contact.html"><i class="fas fa-angle-right me-2 text-success" aria-hidden="true"></i>Partner With Us</a></li>
                        <li><a href="contact.html"><i class="fas fa-angle-right me-2 text-success" aria-hidden="true"></i>Join Our Team</a></li>
                        <li><a href="gallery.html"><i class="fas fa-angle-right me-2 text-success" aria-hidden="true"></i>Field Gallery</a></li>
                        <li><a href="about.html"><i class="fas fa-angle-right me-2 text-success" aria-hidden="true"></i>Our Mission &amp; Values</a></li>
                    </ul>
                </div>
                <div class="col-lg-3 col-md-6">
                    <h4>Contact Us</h4>
                    <div class="mb-3 small" style="color: #BFD3C7;">
                        <p class="mb-2"><i class="fas fa-envelope text-success me-2" aria-hidden="true"></i><a href="mailto:gnep.partnership@gmail.com">gnep.partnership@gmail.com</a></p>
                        <p class="mb-2"><i class="fas fa-phone-alt text-success me-2" aria-hidden="true"></i><a href="tel:+2347065885070">+234 706 588 5070</a></p>
                        <p class="mb-0"><i class="fas fa-map-marker-alt text-success me-2" aria-hidden="true"></i>Katsina State, Nigeria</p>
                    </div>
                    <div class="mt-4 pt-2 border-top border-secondary">
                        <span class="small d-block text-muted mb-2">Connect With GNEP Africa:</span>
                        <a href="https://www.linkedin.com/company/global-nature-environmental-partnership/" target="_blank" rel="noopener noreferrer" class="btn btn-sm btn-outline-light me-2" aria-label="LinkedIn - GNEP Africa"><i class="fab fa-linkedin me-1" aria-hidden="true"></i> LinkedIn</a>
                        <a href="mailto:gnep.partnership@gmail.com" class="btn btn-sm btn-outline-light" aria-label="Email GNEP"><i class="fas fa-envelope me-1" aria-hidden="true"></i> Email</a>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <!-- Bottom Legal Bar -->
    <div class="gnep-legal-bar" aria-label="Legal and Copyright">
        <div class="container">
            <div class="row align-items-center gy-2">
                <div class="col-md-6 text-center text-md-start">
                    &copy; 2026 Global Nature and Environmental Partnership (GNEP Africa). All rights reserved.
                </div>
                <div class="col-md-6 text-center text-md-end">
                    <span class="me-3 text-white-50">Photography &copy; GNEP &amp; AYINET</span>
                    <a href="#" class="text-decoration-none text-muted me-2">Privacy</a>&bull;
                    <a href="#" class="text-decoration-none text-muted mx-2">Terms</a>&bull;
                    <a href="#" class="text-decoration-none text-muted ms-2">Accessibility</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
"""

out_path = os.path.join(BASE_DIR, "cso-policy-workshop.html")
with open(out_path, "w", encoding="utf-8") as f:
    f.write(HTML_CONTENT)
print("Created cso-policy-workshop.html successfully!")
