# GNEP Africa – Interactive 3D Environmental Intelligence Platform

## Overview

This repository hosts the **GNEP Africa** website – a static site that has been transformed into an immersive, interactive 3D environmental intelligence platform. The site retains all existing branding, content, navigation, and backend integrations while adding:

- **CesiumJS 3‑D Earth** as the hero element, with a fallback to the original Three.js canvas for low‑spec browsers.
- **Dark‑mode toggle** (🌙/☀️) that persists the user’s preference via `localStorage`.
- **Global design tokens** implemented as CSS custom properties for consistent colors, typography, spacing, and WCAG AA contrast compliance.
- **Environmental data layer panel** that allows users to overlay NASA MODIS True‑Color imagery and Copernicus Sentinel‑2 NDVI data on the globe.
- **Responsive, accessible UI** built with Bootstrap 5 and custom SCSS.

All of this runs completely client‑side; there are no server‑side components required.

---

## Repository Structure

```
├─ index.html                     # Main page – includes Cesium container and UI
├─ css/
│   ├─ design-tokens.css          # CSS variables for brand colors, dark mode, etc.
│   ├─ style.css                  # Main stylesheet (compiled from SCSS)
│   └─ gnep.css                  # Additional site‑specific styles
├─ scss/
│   ├─ _design-tokens.scss       # SCSS source for design tokens (imported first)
│   ├─ _custom-colors.scss       # Maps CSS variables to Bootstrap SCSS vars
│   └─ bootstrap.scss            # Imports design tokens, custom colors, then Bootstrap
├─ js/
│   ├─ cesium-loader.js          # Lazy‑loads Cesium, provides fallback to Three.js
│   ├─ data-layers.js            # UI for toggling MODIS & Sentinel‑2 layers
│   ├─ dark-mode.js              # Dark‑mode toggle script
│   └─ gnep-3d.js                # Original Three.js hero scene
├─ assets/                        # Images, icons, etc.
├─ partials/                      # Optional reusable HTML snippets (e.g., header/footer)
└─ README.md                     # This file
```

---

## Getting Started (Local Development)

1. **Install dependencies (optional)** – the project is pure static HTML/CSS/JS, so no build tools are required.  If you wish to re‑compile SCSS, install `sass`:
   ```bash
   npm install -g sass
   ```
2. **Compile SCSS (if editing styles)**:
   ```bash
   sass scss/bootstrap.scss css/style.css
   ```
3. **Run a local server** (recommended to avoid CORS issues with Cesium):
   ```bash
   # Using Python (built‑in)
   cd path/to/nature-website-template
   python -m http.server 8000
   # Then open http://localhost:8000 in your browser
   ```
   Or with Node’s `serve`:
   ```bash
   npm install -g serve
   serve -s . -l 8000
   ```

---

## Deployment

### Cloudflare Pages (recommended)
1. **Create a Pages project** in the Cloudflare dashboard.
2. **Connect the GitHub repository** (this repo) to the project.
3. **Set the production branch** to `main` and leave the build command empty (static site).
4. **Deploy** – Cloudflare will automatically build and serve the site at
   `https://<project‑name>.pages.dev`.

### Manual Upload (ZIP)
If you prefer not to use Git integration, you can zip the entire folder and upload it via the Cloudflare Pages UI ("Upload your site"). The zip is already prepared as `gnep_site.zip` in the repository.

---

## Features in Detail

- **CesiumJS Earth** – lazy‑loaded from the official CDN, with Bing Aerial basemap by default.  Users can enable additional layers via the control panel.
- **Data‑Layer Panel** – top‑right fixed panel with checkboxes for:
  - **NASA MODIS Terra (True Color)** – global true‑color imagery.
  - **Copernicus Sentinel‑2 (NDVI)** – cloud‑less NDVI basemap.
- **Dark‑Mode** – toggles a `.dark-mode` class on `<body>`; colors are defined in `css/design-tokens.css`.
- **Design Tokens** – all brand colours, greys, spacing, and border radius are stored as CSS custom properties, making future theming trivial.
- **Accessibility** – WCAG AA contrast ratios are met for all text; focus states are clearly visible; `aria‑label`s are added to interactive elements.

---

## Contributing

1. Fork the repository.
2. Create a feature branch (`git checkout -b feature/awesome‑thing`).
3. Make your changes, run any SCSS recompilation if needed, and test locally.
4. Submit a Pull Request with a clear description of the changes.

---

## License & Credits

- **Content & branding** belong to **Global Nature and Environmental Partnership (GNEP Africa)**.
- **CesiumJS** – © Cesium Labs, Inc. (Apache‑2.0).
- **NASA GIBS** and **Copernicus Sentinel‑2** imagery – used under their respective open data licences (credit shown on the map).
- **Bootstrap** – MIT License.
- **Other third‑party libraries** (jQuery, GSAP, FontAwesome, etc.) are included under their original licences.

---

## Contact

For questions, issues, or feature requests, please open an issue in this repository or contact the GNEP team at
`gnep.partnership@gmail.com`.

---

*This README was generated automatically by the Antigravity AI assistant to document the current state of the GNEP Africa site.*
