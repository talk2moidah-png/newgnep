import json
import os
from PIL import Image

# Exact semantic mapping based on contact sheet analysis
accurate_meta = [
    # (filename, category, title, caption, credit)
    (',,,,,,,,,,,,,,,.jpeg', 'workshops', 'CSO Proposal Writing Breakout', 'Civil society representatives collaborating on climate proposals using laptops.', 'GNEP / The Green Minds Space'),
    ('WhatsApp Image 2026-10-20 at 12.02.27 PM.jpeg', 'workshops', 'Policy Training Hall Session', 'Participants assembled in Katsina conference hall for proposal & policy training.', 'GNEP / The Green Minds Space'),
    ('WhatsApp Image 2026-10-20 at 12.02.28 PM.jpeg', 'workshops', 'Interactive Ideation Board', 'Using participatory sticky-note methods to map local climate adaptation priorities.', 'GNEP / The Green Minds Space'),
    ('WhatsApp Image 2026-10-20 at 12.02.28 PMgfd.jpeg', 'workshops', 'Stakeholder Perspective Dialogue', 'CSO representative presenting key community resilience considerations.', 'GNEP / The Green Minds Space'),
    ('WhatsApp Image 2026-10-20 at 12.02.46 PM.jpeg', 'schools', 'School Climate Action Champions', 'Students and youth champions with economic tree seedlings outside school.', 'GNEP Katsina'),
    ('aaaaaaaaaaaaa.jpeg', 'tree-planting', 'Arid Land Restoration Action', 'Volunteers carrying shovels and seedlings for restoration in Katsina.', 'GNEP / AYINET Katsina'),
    ('cc.jpeg', 'schools', 'Youth Leadership with Seedlings', 'Three GNEP project leads holding tree seedlings in polybags.', 'GNEP Media'),
    ('dddd.jpeg', 'tree-planting', 'Community Restoration Cohort', 'Civic participants and youth holding seedlings before field deployment.', 'GNEP Katsina'),
    ('ddrdt.jpeg', 'tree-planting', 'Field Seedling Planting', 'Youth team kneeling in grass planting economic tree seedlings.', 'GNEP / AYINET Katsina'),
    ('dfghjkl.jpeg', 'tree-planting', 'Soil Preparation with Shovels', 'Preparing planting pits in challenging dryland terrain.', 'GNEP / AYINET Katsina'),
    ('ee.jpeg', 'tree-planting', 'Seedling Distribution & Care', 'Mohammed Labaran Sani and volunteers inspecting seedlings in Katsina.', 'GNEP / AYINET Katsina'),
    ('gf.jpeg', 'workshops', 'Advocacy Strategy Facilitation', 'Lead facilitator outlining policy brief structure and legislative engagement.', 'GNEP / The Green Minds Space'),
    ('gfyibu.jpeg', 'workshops', 'Digital Proposal Labs', 'Hands-on laptop work sessions drafting competitive project proposals.', 'GNEP / The Green Minds Space'),
    ('gtgjyg.jpeg', 'workshops', 'Active Participant Engagement', 'Civic organization leads following technical presentation modules.', 'GNEP / The Green Minds Space'),
    ('ijuhb.jpeg', 'workshops', 'Storytelling & Public Advocacy', 'Speaker demonstrating persuasive communication and elevator pitch skills.', 'GNEP Media'),
    ('ll.jpeg', 'schools', 'School Eco-Literacy Outreach', 'Youth volunteers mobilizing school students for ecological awareness.', 'GNEP Katsina'),
    ('nn.jpeg', 'schools', 'Youth Climate Ambassador', 'Young advocate in GNEP t-shirt holding sapling ready for planting.', 'GNEP Katsina'),
    ('oooooooooo.jpeg', 'research', 'Flood Disaster Policy Brief Presentation', 'Presentation translating climate science into disaster risk reduction briefs.', 'PAUWES / GNEP'),
    ('p.jpeg', 'tree-planting', 'Grassroots Tree Planting in Field', 'Volunteers planting indigenous seedling in Katsina field.', 'GNEP / AYINET Katsina'),
    ('qq.jpeg', 'tree-planting', '150 Economic Seedlings Drive', 'Line of community volunteers holding seedlings during AYINET joint drive.', 'GNEP / AYINET Katsina'),
    ('rr.jpeg', 'research', 'GNEP Field Impact Showcase', 'Founder Mohammed Labaran Sani presenting documented field results.', 'PAUWES / GNEP'),
    ('ss.jpeg', 'workshops', 'Collaborative Grant Writing', 'CSO participants examining funding criteria and research data.', 'GNEP / The Green Minds Space'),
    ('vvf.jpeg', 'workshops', '20 CSO Representatives Cohort', 'Full workshop cohort photo at Katsina State policy & proposal training.', 'GNEP / The Green Minds Space'),
    ('vvvvvvvvvvvvvvvv.jpeg', 'tree-planting', 'Sahel Green Field Action', 'Volunteers planting economic seedlings to counter desertification.', 'GNEP / AYINET Katsina'),
    ('wertyuio.jpeg', 'tree-planting', 'Dryland Planting Under Sun', 'Team of youth digging and planting under clear Sahelian skies.', 'GNEP / AYINET Katsina'),
    ('xcvbn.jpeg', 'workshops', 'Communication & Pitch Session', 'Youth leader practicing climate action elevator pitch.', 'GNEP Media'),
    ('yyyyyyyyyy.jpeg', 'schools', 'GNEP Leadership in Katsina', 'Mohammed Labaran Sani with project leads holding tree seedlings.', 'GNEP Media'),
    ('za.jpeg', 'tree-planting', 'Nursery Stock & Seedling Care', 'Close-up of young tree saplings nurtured for field planting.', 'GNEP / AYINET Katsina')
]

src_dir = r'C:\Users\SURFACE\Downloads\img'
out_dir = r'C:\Users\SURFACE\.gemini\antigravity\scratch\youth-ngo-website\nature-website-template\assets\real\gallery'
os.makedirs(out_dir, exist_ok=True)

cat_labels = {
    'tree-planting': ('Tree Planting', 'bg-success text-white'),
    'workshops': ('CSO Workshop', 'bg-primary text-white'),
    'schools': ('Schools & Youth', 'bg-info text-dark'),
    'research': ('Policy & Research', 'bg-warning text-dark')
}

cards_html = []
for idx, (fname, cat, title, caption, credit) in enumerate(accurate_meta):
    clean_id = f'gnep-{cat}-{idx+1:02d}'
    cat_name, badge_class = cat_labels.get(cat, ('Field Work', 'bg-success text-white'))
    full_path = f'assets/real/gallery/{clean_id}-full.webp'
    thumb_path = f'assets/real/gallery/{clean_id}-thumb.webp'
    
    full_disk = os.path.join(out_dir, f'{clean_id}-full.webp')
    thumb_disk = os.path.join(out_dir, f'{clean_id}-thumb.webp')

    # Convert source image if not already generated
    src_path = os.path.join(src_dir, fname)
    if os.path.exists(src_path):
        im = Image.open(src_path)
        if im.mode in ('RGBA', 'P'):
            im = im.convert('RGB')
        
        # Save full
        im_full = im.copy()
        im_full.thumbnail((1600, 1600), Image.Resampling.LANCZOS)
        im_full.save(full_disk, 'WEBP', quality=82)

        # Save thumb
        im_thumb = im.copy()
        im_thumb.thumbnail((600, 450), Image.Resampling.LANCZOS)
        im_thumb.save(thumb_disk, 'WEBP', quality=80)

    card = f'''                    <!-- Gallery Item: {clean_id} -->
                    <div class="col-lg-4 col-md-6 gallery-item-col" data-category="{cat}">
                        <article class="gallery-card">
                            <div class="gallery-img-container">
                                <a href="{full_path}" data-lightbox="gnep-gallery" data-title="{title} - {caption} (Photo: {credit})">
                                    <img src="{thumb_path}" alt="{title}" class="gallery-img" loading="lazy" width="600" height="450">
                                    <div class="gallery-overlay">
                                        <div class="gallery-overlay-icon">
                                            <i class="fas fa-search-plus" aria-hidden="true"></i>
                                        </div>
                                        <span class="gallery-overlay-text">Expand Photo</span>
                                    </div>
                                </a>
                                <span class="gallery-badge {badge_class}">{cat_name}</span>
                            </div>
                            <div class="gallery-info">
                                <h3 class="gallery-title">{title}</h3>
                                <p class="gallery-caption">{caption}</p>
                                <div class="gallery-credit">
                                    <i class="fas fa-camera me-1 text-muted" aria-hidden="true"></i> {credit}
                                </div>
                            </div>
                        </article>
                    </div>'''
    cards_html.append(card)

cards_joined = '\n'.join(cards_html)

full_html = f'''<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Field Gallery &amp; Documentation | GNEP Africa</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="GNEP Africa gallery, climate action photos, Katsina tree planting, AYINET, CSO workshop, PAUWES, green schools" name="keywords">
    <meta content="Visual records of GNEP Africa field work, community tree planting drives, school climate clubs, and civil society policy workshops." name="description">

    <!-- Google Web Fonts (International Editorial Stack: Inter + Plus Jakarta Sans + Newsreader) -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Newsreader:ital,opsz,wght@0,6..72,400;0,6..72,500;0,6..72,600;1,6..72,400&family=Plus+Jakarta+Sans:wght@500;600;700;800&display=swap" rel="stylesheet"> 

    <!-- Icon Font Stylesheet -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css"/>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/lightbox/css/lightbox.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">

    <!-- GNEP Custom Stylesheet (WCAG AA, Editorial, Responsive) -->
    <link href="css/gnep.css" rel="stylesheet">
</head>

<body>

    <!-- Accessible Skip to Content Link -->
    <a class="skip-to-content" href="#main-content">Skip to main content</a>

    <!-- Spinner Start -->
    <div id="spinner" class="show w-100 vh-100 bg-white position-fixed translate-middle top-50 start-50 d-flex align-items-center justify-content-center" aria-hidden="true">
        <div class="spinner-grow text-primary" role="status">
            <span class="visually-hidden">Loading...</span>
        </div>
    </div>
    <!-- Spinner End -->

    <!-- Header & Navigation Start -->
    <header class="fixed-top">
        <!-- Thin Utility Bar (UNEP Pattern) -->
        <aside class="gnep-topbar d-none d-md-block" aria-label="Quick Links">
            <div class="container d-flex justify-content-between align-items-center">
                <div class="d-flex align-items-center">
                    <a href="index.html#updates"><i class="fas fa-file-alt me-1" aria-hidden="true"></i> Research and Insights</a>
                    <span class="topbar-divider">|</span>
                    <a href="#contact"><i class="fas fa-envelope me-1" aria-hidden="true"></i> Contact</a>
                    <span class="topbar-divider">|</span>
                    <a href="https://www.linkedin.com/company/global-nature-environmental-partnership/" target="_blank" rel="noopener noreferrer"><i class="fab fa-linkedin me-1" aria-hidden="true"></i> LinkedIn</a>
                </div>
                <div class="d-flex align-items-center text-white-50 small">
                    <span class="me-3"><i class="fas fa-map-marker-alt text-white me-1" aria-hidden="true"></i> Katsina State, Nigeria</span>
                    <a href="mailto:gnep.partnership@gmail.com" class="text-white"><i class="fas fa-paper-plane me-1" aria-hidden="true"></i> gnep.partnership@gmail.com</a>
                </div>
            </div>
        </aside>

        <!-- Main Navbar -->
        <nav class="navbar navbar-expand-lg gnep-navbar" aria-label="Main Navigation">
            <div class="container">
                <!-- Brand / Logo -->
                <a href="index.html" class="gnep-brand-wrap" aria-label="GNEP Africa Homepage">
                    <img src="assets/real/gnep-logo.webp" alt="GNEP Logo" class="gnep-brand-logo" width="160" height="48">
                    <div class="gnep-brand-text d-none d-sm-block">
                        <span class="gnep-brand-title">GNEP Africa</span>
                        <span class="gnep-brand-sub">Global Nature &amp; Environmental Partnership</span>
                    </div>
                </a>

                <!-- Mobile Hamburger with large touch target -->
                <button class="navbar-toggler py-2 px-3" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation menu">
                    <span class="fa fa-bars text-dark fs-5"></span>
                </button>

                <!-- Navigation Items -->
                <div class="collapse navbar-collapse" id="navbarCollapse">
                    <ul class="navbar-nav ms-auto align-items-lg-center">
                        <li class="nav-item">
                            <a href="index.html#about" class="nav-link">About GNEP</a>
                        </li>
                        
                        <!-- Our Work Dropdown -->
                        <li class="nav-item dropdown">
                            <a href="index.html#focus-areas" class="nav-link dropdown-toggle" id="workDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                Our Work
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="workDropdown">
                                <li><a class="dropdown-item" href="index.html#focus-areas">1. Climate Action &amp; Resilience</a></li>
                                <li><a class="dropdown-item" href="index.html#focus-areas">2. Nature &amp; Ecosystem Restoration</a></li>
                                <li><a class="dropdown-item" href="index.html#focus-areas">3. Environmental Governance &amp; Policy</a></li>
                                <li><a class="dropdown-item" href="index.html#focus-areas">4. Youth Leadership &amp; Participation</a></li>
                                <li><a class="dropdown-item" href="index.html#focus-areas">5. WEFE Nexus <span class="badge bg-secondary ms-1 text-dark">Strategic Direction</span></a></li>
                                <li><a class="dropdown-item" href="index.html#focus-areas">6. Research &amp; Capacity Development</a></li>
                            </ul>
                        </li>

                        <!-- Updates Dropdown (Gallery Active) -->
                        <li class="nav-item dropdown">
                            <a href="index.html#updates" class="nav-link dropdown-toggle active" id="updatesDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                Updates
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="updatesDropdown">
                                <li><a class="dropdown-item" href="index.html#updates">Events &amp; Workshops</a></li>
                                <li><a class="dropdown-item" href="index.html#updates">Research &amp; Insights</a></li>
                                <li><a class="dropdown-item active" href="gallery.html">Field Gallery</a></li>
                            </ul>
                        </li>

                        <li class="nav-item">
                            <a href="index.html#get-involved" class="nav-link">Get Involved</a>
                        </li>
                    </ul>

                    <!-- Highlighted CTA (No donate button) -->
                    <div class="d-flex align-items-center ms-lg-3 mt-3 mt-lg-0">
                        <a href="index.html#partner-with-us" class="btn-partner-nav text-center w-100 w-lg-auto">Partner With Us</a>
                    </div>
                </div>
            </div>
        </nav>
    </header>
    <!-- Header & Navigation End -->

    <!-- Main Content Container -->
    <main id="main-content">

        <!-- Page Breadcrumb Banner Start -->
        <section class="gallery-hero-banner" aria-label="Gallery Introduction">
            <div class="container text-center">
                <span class="gallery-hero-badge"><i class="fas fa-camera me-1" aria-hidden="true"></i> Documented Impact &bull; Real Field Records</span>
                <h1 class="gallery-hero-title">GNEP Field Gallery</h1>
                <p class="gallery-hero-desc">
                    Authentic visual documentation of our community tree planting drives, school climate clubs, civil society policy workshops, and PAUWES research presentations across Katsina State and Africa.
                </p>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb justify-content-center mb-0">
                        <li class="breadcrumb-item"><a href="index.html" class="text-white-50">Home</a></li>
                        <li class="breadcrumb-item"><a href="index.html#updates" class="text-white-50">Updates</a></li>
                        <li class="breadcrumb-item active text-white" aria-current="page">Field Gallery</li>
                    </ol>
                </nav>
            </div>
        </section>
        <!-- Page Breadcrumb Banner End -->

        <!-- Gallery Section Start -->
        <section class="gallery-main-section" aria-label="Field Photo Gallery">
            <div class="container">
                
                <!-- Filter Tabs -->
                <div class="gallery-filter-wrap text-center mb-5">
                    <div class="btn-group flex-wrap gallery-filter-group" role="group" aria-label="Gallery category filters">
                        <button type="button" class="btn btn-filter active" data-filter="all">All Documentation <span class="filter-count">28</span></button>
                        <button type="button" class="btn btn-filter" data-filter="tree-planting"><i class="fas fa-seedling me-1"></i> Tree Planting <span class="filter-count">10</span></button>
                        <button type="button" class="btn btn-filter" data-filter="workshops"><i class="fas fa-users me-1"></i> CSO Workshops <span class="filter-count">11</span></button>
                        <button type="button" class="btn btn-filter" data-filter="schools"><i class="fas fa-graduation-cap me-1"></i> Schools &amp; Youth <span class="filter-count">5</span></button>
                        <button type="button" class="btn btn-filter" data-filter="research"><i class="fas fa-microscope me-1"></i> Policy &amp; Research <span class="filter-count">2</span></button>
                    </div>
                </div>

                <!-- Gallery Photo Grid -->
                <div class="row g-4" id="galleryGrid">
{cards_joined}
                </div>

                <!-- Lightbox Note / Trust Badge -->
                <div class="text-center mt-5 pt-3">
                    <span class="evidence-footnote-badge">
                        <i class="fas fa-check-circle text-success me-1" aria-hidden="true"></i>
                        Click any photo above to inspect in high-resolution lightbox with complete field notes and partner credits.
                    </span>
                </div>
            </div>
        </section>
        <!-- Gallery Section End -->

        <!-- Field Collaboration CTA Banner -->
        <section class="gallery-cta-banner">
            <div class="container text-center">
                <span class="gnep-section-tag text-white-50">Get Involved</span>
                <h2 class="h2 text-white fw-bold mb-3">Partner With GNEP on Field Action</h2>
                <p class="text-white-50 max-w-600 mx-auto mb-4" style="max-width: 650px;">
                    Whether establishing school climate clubs, supporting community tree planting in Katsina, or conducting policy training for CSOs, we welcome collaborative partnerships.
                </p>
                <div class="d-flex flex-wrap justify-content-center gap-3">
                    <a href="index.html#partner-with-us" class="btn btn-gnep-hero-primary">Partner With Us</a>
                    <a href="mailto:gnep.partnership@gmail.com" class="btn btn-outline-light px-4 py-2" style="border-radius: 8px;">Contact Our Team</a>
                </div>
            </div>
        </section>

    </main>
    <!-- Main Content End -->

    <!-- Shared Footer (UNEP & WWF Pattern) -->
    <footer class="gnep-footer" id="contact" aria-label="Footer and Contact Information">
        <div class="container">
            <div class="row g-4">
                <!-- Col 1: About GNEP -->
                <div class="col-lg-4 col-md-6">
                    <div class="d-flex align-items-center mb-3">
                        <img src="assets/real/gnep-logo.webp" alt="GNEP Logo" class="bg-white p-1 rounded" width="130" height="40" style="object-fit: contain;">
                    </div>
                    <p class="small text-light-50 mb-3" style="color: #BFD3C7;">
                        Global Nature and Environmental Partnership (GNEP Africa) is a youth-led initiative connecting climate research, policy, and education with practical community action across Africa.
                    </p>
                    <div class="small" style="color: #9EBAAB;">
                        <div><strong>Founded:</strong> 2025</div>
                        <div><strong>Base:</strong> Katsina State, Nigeria &bull; <strong>Outlook:</strong> Africa</div>
                    </div>

                    <!-- "Our Approach" Statement -->
                    <div class="gnep-footer-approach">
                        <strong>Our Approach:</strong> We are committed to evidence-informed action, strictly verified data reporting, and transparently crediting all community and institutional partners.
                    </div>
                </div>

                <!-- Col 2: Our Work -->
                <div class="col-lg-3 col-md-6">
                    <h4>Our Work</h4>
                    <ul class="footer-link-list">
                        <li><a href="index.html#focus-areas"><i class="fas fa-angle-right me-2 text-success" aria-hidden="true"></i>Climate Action &amp; Resilience</a></li>
                        <li><a href="index.html#focus-areas"><i class="fas fa-angle-right me-2 text-success" aria-hidden="true"></i>Nature &amp; Ecosystem Restoration</a></li>
                        <li><a href="index.html#focus-areas"><i class="fas fa-angle-right me-2 text-success" aria-hidden="true"></i>Environmental Governance &amp; Policy</a></li>
                        <li><a href="index.html#focus-areas"><i class="fas fa-angle-right me-2 text-success" aria-hidden="true"></i>Youth Leadership &amp; Participation</a></li>
                        <li><a href="index.html#focus-areas"><i class="fas fa-angle-right me-2 text-success" aria-hidden="true"></i>WEFE Nexus (Strategic Direction)</a></li>
                        <li><a href="index.html#focus-areas"><i class="fas fa-angle-right me-2 text-success" aria-hidden="true"></i>Research &amp; Capacity Development</a></li>
                    </ul>
                </div>

                <!-- Col 3: Get Involved -->
                <div class="col-lg-2 col-md-6">
                    <h4>Get Involved</h4>
                    <ul class="footer-link-list">
                        <li><a href="index.html#partner-with-us"><i class="fas fa-angle-right me-2 text-success" aria-hidden="true"></i>Partner With Us</a></li>
                        <li><a href="index.html#get-involved"><i class="fas fa-angle-right me-2 text-success" aria-hidden="true"></i>Join Our Team</a></li>
                        <li><a href="index.html#hero"><i class="fas fa-angle-right me-2 text-success" aria-hidden="true"></i>Subscribe to Updates</a></li>
                        <li><a href="gallery.html"><i class="fas fa-angle-right me-2 text-success" aria-hidden="true"></i>Field Gallery</a></li>
                        <li><a href="index.html#about"><i class="fas fa-angle-right me-2 text-success" aria-hidden="true"></i>Our Mission &amp; Values</a></li>
                    </ul>
                </div>

                <!-- Col 4: Contact & Social (Only verified LinkedIn) -->
                <div class="col-lg-3 col-md-6">
                    <h4>Contact Us</h4>
                    <div class="mb-3 small" style="color: #BFD3C7;">
                        <p class="mb-2">
                            <i class="fas fa-envelope text-success me-2" aria-hidden="true"></i>
                            <a href="mailto:gnep.partnership@gmail.com">gnep.partnership@gmail.com</a>
                        </p>
                        <p class="mb-2">
                            <i class="fas fa-phone-alt text-success me-2" aria-hidden="true"></i>
                            <a href="tel:+2347065885070">+234 706 588 5070</a>
                        </p>
                        <p class="mb-0">
                            <i class="fas fa-map-marker-alt text-success me-2" aria-hidden="true"></i>
                            Katsina State, Nigeria
                        </p>
                    </div>

                    <div class="mt-4 pt-2 border-top border-secondary">
                        <span class="small d-block text-muted mb-2">Connect With GNEP Africa:</span>
                        <a href="https://www.linkedin.com/company/global-nature-environmental-partnership/" target="_blank" rel="noopener noreferrer" class="btn btn-sm btn-outline-light me-2" title="LinkedIn - GNEP Africa" aria-label="LinkedIn - GNEP Africa">
                            <i class="fab fa-linkedin me-1" aria-hidden="true"></i> LinkedIn
                        </a>
                        <a href="mailto:gnep.partnership@gmail.com" class="btn btn-sm btn-outline-light" title="Email GNEP" aria-label="Email GNEP">
                            <i class="fas fa-envelope me-1" aria-hidden="true"></i> Email
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <!-- Bottom Legal Bar -->
    <div class="gnep-legal-bar" aria-label="Legal and Copyright">
        <div class="container">
            <div class="row align-items-center gy-2">
                <div class="col-md-6 text-center text-md-start">
                    &copy; 2026 Global Nature and Environmental Partnership (GNEP Africa). All rights reserved.
                </div>
                <div class="col-md-6 text-center text-md-end">
                    <span class="me-3 text-white-50">Photography &copy; GNEP &amp; AYINET</span>
                    <a href="#" class="text-decoration-none text-muted me-2">Privacy</a>&bull;
                    <a href="#" class="text-decoration-none text-muted mx-2">Terms</a>&bull;
                    <a href="#" class="text-decoration-none text-muted ms-2">Accessibility</a>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer End -->

    <!-- Back to Top -->
    <a href="#" class="btn btn-primary btn-md-square back-to-top" aria-label="Back to top of page">
        <i class="fa fa-arrow-up" aria-hidden="true"></i>
    </a>   

    <!-- JavaScript Libraries -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/counterup/counterup.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/lightbox/js/lightbox.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>

    <!-- Gallery Filtering Script -->
    <script>
        $(document).ready(function() {{
            $('.btn-filter').on('click', function() {{
                $('.btn-filter').removeClass('active');
                $(this).addClass('active');

                var filter = $(this).attr('data-filter');
                if (filter === 'all') {{
                    $('.gallery-item-col').fadeIn(300);
                }} else {{
                    $('.gallery-item-col').hide();
                    $('.gallery-item-col[data-category=\"' + filter + '\"]').fadeIn(300);
                }}
            }});
        }});
    </script>

</body>
</html>
'''

with open(r'C:\Users\SURFACE\.gemini\antigravity\scratch\youth-ngo-website\nature-website-template\gallery.html', 'w', encoding='utf-8') as f:
    f.write(full_html)

print('Updated gallery.html and converted all 28 images successfully!')
