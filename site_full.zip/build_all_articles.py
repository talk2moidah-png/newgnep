# -*- coding: utf-8 -*-
"""
Builder for all full GNEP articles:
1. tree-planting-150-seedlings.html
2. communicating-environmental-issues.html
3. turning-research-into-action.html
4. youth-environmental-action.html
5. nigeria-heat-emergency-policy-brief.html
And updates all links in index.html and events.html.
"""

import os
import zipfile
import xml.etree.ElementTree as ET

BASE_DIR = r"C:\Users\SURFACE\.gemini\antigravity\scratch\youth-ngo-website\nature-website-template"
DOWNLOADS = r"C:\Users\SURFACE\Downloads"

def get_docx_paragraphs(filename):
    path = os.path.join(DOWNLOADS, filename)
    if not os.path.exists(path):
        return []
    with zipfile.ZipFile(path) as z:
        xml_content = z.read("word/document.xml")
    tree = ET.fromstring(xml_content)
    paras = []
    for p in tree.iter("{http://schemas.openxmlformats.org/wordprocessingml/2006/main}p"):
        t = "".join([n.text for n in p.iter("{http://schemas.openxmlformats.org/wordprocessingml/2006/main}t") if n.text])
        if t.strip():
            paras.append(t.strip())
    return paras

# Common page template wrapper
def render_article_page(meta_title, meta_desc, og_image, breadcrumb_title, hero_badges, hero_title, hero_lead, featured_img, featured_caption, body_html, sidebar_facts, related_links):
    badges_html = "".join([f'<span class="article-meta-badge">{b}</span>' for b in hero_badges])
    facts_html = "".join([f'''
        <div class="article-key-fact">
            <i class="{icon}"></i>
            <div><strong>{title}:</strong><br><span class="text-muted small">{val}</span></div>
        </div>
    ''' for icon, title, val in sidebar_facts])
    
    related_html = "".join([f'''
        <li class="mb-3">
            <a href="{url}" class="text-decoration-none fw-bold text-dark d-block">
                <i class="{icon} text-success me-1"></i> {title}
            </a>
            <span class="text-muted" style="font-size: 0.8rem;">{sub}</span>
        </li>
    ''' for url, icon, title, sub in related_links])

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>{meta_title} | GNEP Africa</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="GNEP Africa, environmental action, climate resilience, Katsina, Nigeria" name="keywords">
    <meta content="{meta_desc}" name="description">

    <!-- Open Graph -->
    <meta property="og:title" content="{meta_title}">
    <meta property="og:description" content="{meta_desc}">
    <meta property="og:image" content="{og_image}">
    <meta property="og:type" content="article">

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Newsreader:ital,opsz,wght@0,6..72,400;0,6..72,500;0,6..72,600;1,6..72,400&family=Plus+Jakarta+Sans:wght@500;600;700;800&display=swap" rel="stylesheet"> 

    <!-- Icon Font Stylesheet -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css"/>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/lightbox/css/lightbox.min.css" rel="stylesheet">

    <!-- Customized Bootstrap & Site Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/gnep.css" rel="stylesheet">

    <style>
        .article-hero {{
            position: relative;
            background: linear-gradient(135deg, #0B2516 0%, #153E26 60%, #1A4D2E 100%);
            padding-top: 140px;
            padding-bottom: 70px;
            color: #ffffff;
            overflow: hidden;
        }}
        .article-hero::before {{
            content: '';
            position: absolute;
            inset: 0;
            background: radial-gradient(circle at 80% 20%, rgba(16, 185, 129, 0.2) 0%, transparent 60%);
            pointer-events: none;
        }}
        .article-meta-badge {{
            display: inline-flex;
            align-items: center;
            gap: 0.4rem;
            background: rgba(255, 255, 255, 0.12);
            color: #E2E8F0;
            font-size: 0.82rem;
            font-weight: 600;
            padding: 0.35rem 0.85rem;
            border-radius: 50px;
            border: 1px solid rgba(255, 255, 255, 0.2);
        }}
        .article-body-content {{
            font-size: 1.05rem;
            line-height: 1.8;
            color: #2D3748;
        }}
        .article-body-content h2, .article-body-content h3 {{
            font-family: 'Plus Jakarta Sans', sans-serif;
            font-weight: 700;
            color: #0B2516;
            margin-top: 2.5rem;
            margin-bottom: 1rem;
        }}
        .article-body-content p {{
            margin-bottom: 1.35rem;
        }}
        .article-quote-box {{
            font-family: 'Newsreader', Georgia, serif;
            font-style: italic;
            font-size: 1.25rem;
            line-height: 1.6;
            color: #0B2516;
            border-left: 4px solid #10B981;
            padding: 1.5rem 1.75rem;
            background: #F0FDF4;
            border-radius: 0 10px 10px 0;
            margin: 2.25rem 0;
        }}
        .article-sidebar-box {{
            background: #FAFCF9;
            border-radius: 12px;
            padding: 1.75rem;
            border: 1px solid #E2E8F0;
            margin-bottom: 2rem;
        }}
        .article-sidebar-title {{
            font-size: 0.8rem;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            font-weight: 700;
            color: #718096;
            margin-bottom: 1rem;
        }}
        .article-key-fact {{
            display: flex;
            align-items: flex-start;
            gap: 0.75rem;
            margin-bottom: 1rem;
            font-size: 0.92rem;
        }}
        .article-key-fact:last-child {{
            margin-bottom: 0;
        }}
        .article-key-fact i {{
            color: #15803D;
            margin-top: 4px;
            font-size: 1rem;
            flex-shrink: 0;
        }}
    </style>
</head>

<body>
    <!-- Skip to main content -->
    <a class="skip-to-content" href="#main-content">Skip to main content</a>

    <!-- Topbar & Navigation -->
    <header class="fixed-top">
        <aside class="gnep-topbar d-none d-md-block" aria-label="Quick Links">
            <div class="container d-flex justify-content-between align-items-center">
                <div class="d-flex align-items-center">
                    <a href="events.html"><i class="fas fa-file-alt me-1" aria-hidden="true"></i> Research and Insights</a>
                    <span class="topbar-divider">|</span>
                    <a href="contact.html"><i class="fas fa-envelope me-1" aria-hidden="true"></i> Contact</a>
                    <span class="topbar-divider">|</span>
                    <a href="https://www.linkedin.com/company/global-nature-environmental-partnership/" target="_blank" rel="noopener noreferrer"><i class="fab fa-linkedin me-1" aria-hidden="true"></i> LinkedIn</a>
                </div>
                <div class="d-flex align-items-center text-white-50 small">
                    <span class="me-3"><i class="fas fa-map-marker-alt text-white me-1" aria-hidden="true"></i> Katsina State, Nigeria</span>
                    <a href="mailto:gnep.partnership@gmail.com" class="text-white"><i class="fas fa-paper-plane me-1" aria-hidden="true"></i> gnep.partnership@gmail.com</a>
                </div>
            </div>
        </aside>

        <nav class="navbar navbar-expand-lg gnep-navbar" aria-label="Main Navigation">
            <div class="container">
                <a href="index.html" class="gnep-brand-wrap" aria-label="GNEP Africa Homepage">
                    <img src="assets/real/gnep-logo.webp" alt="GNEP Logo" class="gnep-brand-logo" width="160" height="48">
                    <div class="gnep-brand-text d-none d-sm-block">
                        <span class="gnep-brand-title">GNEP Africa</span>
                        <span class="gnep-brand-sub">Global Nature &amp; Environmental Partnership</span>
                    </div>
                </a>
                <button class="navbar-toggler py-2 px-3" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation menu">
                    <span class="fa fa-bars text-dark fs-5"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarCollapse">
                    <ul class="navbar-nav ms-auto align-items-lg-center">
                        <li class="nav-item"><a href="about.html" class="nav-link">About GNEP</a></li>
                        <li class="nav-item dropdown">
                            <a href="index.html#focus-areas" class="nav-link dropdown-toggle" id="workDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">Our Work</a>
                            <ul class="dropdown-menu" aria-labelledby="workDropdown">
                                <li><a class="dropdown-item" href="index.html#focus-areas">1. Climate Action &amp; Resilience</a></li>
                                <li><a class="dropdown-item" href="index.html#focus-areas">2. Nature &amp; Ecosystem Restoration</a></li>
                                <li><a class="dropdown-item" href="index.html#focus-areas">3. Environmental Governance &amp; Policy</a></li>
                                <li><a class="dropdown-item" href="index.html#focus-areas">4. Youth Leadership &amp; Participation</a></li>
                                <li><a class="dropdown-item" href="index.html#focus-areas">5. WEFE Nexus <span class="badge bg-secondary ms-1 text-dark">Strategic Direction</span></a></li>
                                <li><a class="dropdown-item" href="index.html#focus-areas">6. Research &amp; Capacity Development</a></li>
                            </ul>
                        </li>
                        <li class="nav-item dropdown">
                            <a href="events.html" class="nav-link dropdown-toggle active" id="updatesDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false" aria-current="page">Updates</a>
                            <ul class="dropdown-menu" aria-labelledby="updatesDropdown">
                                <li><a class="dropdown-item" href="events.html">Events &amp; Workshops</a></li>
                                <li><a class="dropdown-item" href="events.html">Research &amp; Insights</a></li>
                                <li><a class="dropdown-item" href="gallery.html">Field Gallery</a></li>
                            </ul>
                        </li>
                        <li class="nav-item"><a href="contact.html" class="nav-link">Get Involved</a></li>
                    </ul>
                    <div class="d-flex align-items-center ms-lg-3 mt-3 mt-lg-0">
                        <a href="contact.html" class="btn-partner-nav text-center w-100 w-lg-auto">Partner With Us</a>
                    </div>
                </div>
            </div>
        </nav>
    </header>

    <main id="main-content">
        <!-- Hero Section -->
        <section class="article-hero" aria-label="Article Header">
            <div class="container">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb" style="background: none; padding: 0; margin-bottom: 1.5rem;">
                        <li class="breadcrumb-item"><a href="index.html" class="text-white-50 text-decoration-none">Home</a></li>
                        <li class="breadcrumb-item"><a href="events.html" class="text-white-50 text-decoration-none">Updates &amp; Field Work</a></li>
                        <li class="breadcrumb-item active text-white" aria-current="page">{breadcrumb_title}</li>
                    </ol>
                </nav>

                <div class="d-flex flex-wrap gap-2 mb-3">
                    {badges_html}
                </div>

                <h1 class="display-5 fw-bold text-white mb-3" style="max-width: 900px; line-height: 1.25;">
                    {hero_title}
                </h1>
                
                <p class="lead text-white-50 mb-0" style="max-width: 800px; font-size: 1.2rem;">
                    {hero_lead}
                </p>
            </div>
        </section>

        <!-- Main Body Content -->
        <section class="py-5 bg-white" aria-label="Article Body">
            <div class="container">
                <div class="row g-5">
                    <!-- Article Column -->
                    <div class="col-lg-8">
                        <div class="mb-4 rounded-3 overflow-hidden shadow-sm border">
                            <img src="{featured_img}" alt="{hero_title}" class="img-fluid w-100" style="object-fit: cover; max-height: 480px;">
                            <div class="p-3 bg-light border-top small text-muted d-flex justify-content-between align-items-center">
                                <span><i class="fas fa-camera text-success me-1"></i> {featured_caption}</span>
                                <span>GNEP Africa Documentation</span>
                            </div>
                        </div>

                        <div class="article-body-content">
                            {body_html}

                            <div class="mt-5 pt-4 border-top d-flex flex-wrap gap-3">
                                <a href="contact.html" class="btn btn-success"><i class="fas fa-handshake me-2"></i>Partner With GNEP</a>
                                <a href="events.html" class="btn btn-outline-dark"><i class="fas fa-arrow-left me-2"></i>Back to All Updates</a>
                                <a href="gallery.html" class="btn btn-outline-success"><i class="fas fa-images me-2"></i>View in Field Gallery</a>
                            </div>
                        </div>
                    </div>

                    <!-- Sidebar Column -->
                    <div class="col-lg-4">
                        <div class="article-sidebar-box">
                            <div class="article-sidebar-title">Key Information</div>
                            {facts_html}
                        </div>

                        <div class="article-sidebar-box">
                            <div class="article-sidebar-title">Related Field Stories</div>
                            <ul class="list-unstyled small mb-0">
                                {related_html}
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>

    <!-- Standard GNEP Footer -->
    <footer class="gnep-footer" id="contact" aria-label="Footer and Contact Information">
        <div class="container">
            <div class="row g-4">
                <div class="col-lg-4 col-md-6">
                    <div class="d-flex align-items-center mb-3">
                        <img src="assets/real/gnep-logo.webp" alt="GNEP Logo" class="bg-white p-1 rounded" width="130" height="40" style="object-fit: contain;">
                    </div>
                    <p class="small text-light-50 mb-3" style="color: #BFD3C7;">
                        Global Nature and Environmental Partnership (GNEP Africa) is a youth-led initiative connecting climate research, policy, and education with practical community action across Africa.
                    </p>
                    <div class="small" style="color: #9EBAAB;">
                        <div><strong>Founded:</strong> 2025</div>
                        <div><strong>Base:</strong> Katsina State, Nigeria &bull; <strong>Outlook:</strong> Africa</div>
                    </div>
                    <div class="gnep-footer-approach mt-3">
                        <strong>Our Approach:</strong> We are committed to evidence-informed action, strictly verified data reporting, and transparently crediting all community and institutional partners.
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <h4>Our Work</h4>
                    <ul class="footer-link-list">
                        <li><a href="index.html#focus-areas"><i class="fas fa-angle-right me-2 text-success" aria-hidden="true"></i>Climate Action &amp; Resilience</a></li>
                        <li><a href="index.html#focus-areas"><i class="fas fa-angle-right me-2 text-success" aria-hidden="true"></i>Nature &amp; Ecosystem Restoration</a></li>
                        <li><a href="index.html#focus-areas"><i class="fas fa-angle-right me-2 text-success" aria-hidden="true"></i>Environmental Governance &amp; Policy</a></li>
                        <li><a href="index.html#focus-areas"><i class="fas fa-angle-right me-2 text-success" aria-hidden="true"></i>Youth Leadership &amp; Participation</a></li>
                        <li><a href="index.html#focus-areas"><i class="fas fa-angle-right me-2 text-success" aria-hidden="true"></i>WEFE Nexus (Strategic Direction)</a></li>
                        <li><a href="index.html#focus-areas"><i class="fas fa-angle-right me-2 text-success" aria-hidden="true"></i>Research &amp; Capacity Development</a></li>
                    </ul>
                </div>
                <div class="col-lg-2 col-md-6">
                    <h4>Get Involved</h4>
                    <ul class="footer-link-list">
                        <li><a href="contact.html"><i class="fas fa-angle-right me-2 text-success" aria-hidden="true"></i>Partner With Us</a></li>
                        <li><a href="contact.html"><i class="fas fa-angle-right me-2 text-success" aria-hidden="true"></i>Join Our Team</a></li>
                        <li><a href="gallery.html"><i class="fas fa-angle-right me-2 text-success" aria-hidden="true"></i>Field Gallery</a></li>
                        <li><a href="about.html"><i class="fas fa-angle-right me-2 text-success" aria-hidden="true"></i>Our Mission &amp; Values</a></li>
                    </ul>
                </div>
                <div class="col-lg-3 col-md-6">
                    <h4>Contact Us</h4>
                    <div class="mb-3 small" style="color: #BFD3C7;">
                        <p class="mb-2"><i class="fas fa-envelope text-success me-2" aria-hidden="true"></i><a href="mailto:gnep.partnership@gmail.com">gnep.partnership@gmail.com</a></p>
                        <p class="mb-2"><i class="fas fa-phone-alt text-success me-2" aria-hidden="true"></i><a href="tel:+2347065885070">+234 706 588 5070</a></p>
                        <p class="mb-0"><i class="fas fa-map-marker-alt text-success me-2" aria-hidden="true"></i>Katsina State, Nigeria</p>
                    </div>
                    <div class="mt-4 pt-2 border-top border-secondary">
                        <span class="small d-block text-muted mb-2">Connect With GNEP Africa:</span>
                        <a href="https://www.linkedin.com/company/global-nature-environmental-partnership/" target="_blank" rel="noopener noreferrer" class="btn btn-sm btn-outline-light me-2" aria-label="LinkedIn - GNEP Africa"><i class="fab fa-linkedin me-1" aria-hidden="true"></i> LinkedIn</a>
                        <a href="mailto:gnep.partnership@gmail.com" class="btn btn-sm btn-outline-light" aria-label="Email GNEP"><i class="fas fa-envelope me-1" aria-hidden="true"></i> Email</a>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <!-- Bottom Legal Bar -->
    <div class="gnep-legal-bar" aria-label="Legal and Copyright">
        <div class="container">
            <div class="row align-items-center gy-2">
                <div class="col-md-6 text-center text-md-start">
                    &copy; 2026 Global Nature and Environmental Partnership (GNEP Africa). All rights reserved.
                </div>
                <div class="col-md-6 text-center text-md-end">
                    <span class="me-3 text-white-50">Photography &copy; GNEP &amp; AYINET</span>
                    <a href="#" class="text-decoration-none text-muted me-2">Privacy</a>&bull;
                    <a href="#" class="text-decoration-none text-muted mx-2">Terms</a>&bull;
                    <a href="#" class="text-decoration-none text-muted ms-2">Accessibility</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
"""

# =========================================================================
# 1. BUILD: tree-planting-150-seedlings.html
# =========================================================================
tree_body = """
<p class="lead text-dark fw-normal" style="font-size: 1.15rem; line-height: 1.8;">
    The Global Nature and Environmental Partnership (GNEP), in collaboration with the African Youth Initiative Network (AYINET), implemented a tree-planting initiative in Katsina State, Nigeria, involving the planting of 150 economic tree seedlings. The initiative reflects a shared commitment to environmental restoration, sustainable land management, and community participation in addressing environmental challenges across the Sahel.
</p>

<p>
    In northern Nigeria, environmental pressures, including land degradation, irregular rainfall, rising temperatures, and desertification risks, place increasing strain on agricultural livelihoods and local ecosystems. Tree planting and landscape restoration can contribute to addressing these challenges when supported by appropriate species selection, community involvement, and sustained maintenance.
</p>

<div class="article-quote-box">
    &ldquo;The planting of 150 economic tree seedlings represents a tangible starting point for local restoration. With sustained care, effective partnerships, and continued community participation, initiatives of this kind can support broader efforts to strengthen ecosystem health and build resilience to environmental pressures.&rdquo;
</div>

<h2>Supporting Environmental Restoration</h2>
<p>
    The initiative focused on planting economic tree seedlings to support environmental rehabilitation and strengthen local green spaces. Beyond their potential environmental benefits, suitable economic tree species can provide communities with products and resources that contribute to livelihoods over time.
</p>
<p>
    Trees can help protect soil from erosion, improve soil structure, provide shade, support biodiversity, and contribute to carbon storage. Depending on the species and local conditions, they may also offer food, fodder, and other useful products.
</p>
<p>
    In areas affected by land degradation, these benefits depend on selecting species adapted to local conditions, planting at appropriate times, and ensuring that seedlings receive adequate care during their establishment.
</p>

<!-- Image Break -->
<div class="my-4 rounded-3 overflow-hidden shadow-sm border">
    <img src="assets/real/tree-planting-action.webp" alt="Youth planting economic seedlings in Katsina" class="img-fluid w-100" style="object-fit: cover;">
    <div class="p-2 bg-light border-top small text-muted text-center">
        Youth volunteers and community members establishing seedling roots in Katsina State soil.
    </div>
</div>

<h2>Partnerships for Local Environmental Action</h2>
<p>
    The collaboration between GNEP and AYINET demonstrates the value of partnerships in delivering practical environmental initiatives. By bringing organisations together around a shared objective, such activities can create opportunities for community participation and strengthen awareness of environmental stewardship.
</p>
<p>
    For GNEP, the initiative forms part of its broader interest in climate resilience, nature restoration, and locally driven environmental action. It also provides a practical entry point for engaging communities in discussions about land management, climate adaptation, and the relationship between healthy ecosystems and sustainable livelihoods.
</p>

<h2>Beyond Planting: Sustaining the Impact</h2>
<p>
    Planting seedlings is an important first step in restoration, but the longer-term value of the intervention will depend on their survival and growth. Water availability, soil conditions, grazing pressure, protection from damage, and regular monitoring can all influence the success of tree-planting initiatives in semi-arid environments.
</p>
<p>
    Continued monitoring would help establish how many seedlings survive, which species perform best, and what environmental or livelihood benefits emerge over time. Documenting these results would also provide useful evidence for improving future restoration activities in Katsina State and other parts of northern Nigeria.
</p>

<h2>Advancing Community Resilience</h2>
<p>
    Through this initiative, GNEP and AYINET contribute to a wider effort to encourage practical environmental action and promote greater community awareness of sustainable land management.
</p>
<p>
    The planting of 150 economic tree seedlings represents a tangible starting point for local restoration. With sustained care, effective partnerships, and continued community participation, initiatives of this kind can support broader efforts to strengthen ecosystem health and build resilience to environmental pressures.
</p>

<div class="p-4 bg-light rounded-3 border-start border-4 border-success mt-4">
    <h3 class="h6 fw-bold text-dark mb-2">About GNEP &amp; Project Partner</h3>
    <p class="small text-muted mb-1">
        The Global Nature and Environmental Partnership (GNEP) is a youth-led environmental initiative based in Katsina State, Nigeria. Its areas of interest include climate action, environmental sustainability, youth engagement, policy advocacy, nature restoration, and capacity development.
    </p>
    <p class="small text-muted mb-0">
        <strong>Project Partner:</strong> African Youth Initiative Network (AYINET).
    </p>
</div>
"""

tree_page_html = render_article_page(
    meta_title="GNEP & AYINET Plant 150 Economic Tree Seedlings in Katsina State",
    meta_desc="GNEP and AYINET planted 150 economic tree seedlings in Katsina State to advance ecosystem restoration and Sahelian climate resilience.",
    og_image="assets/real/tree-planting-action.webp",
    breadcrumb_title="150 Economic Tree Seedlings",
    hero_badges=[
        '<i class="fas fa-calendar-alt text-success me-1"></i> 2025–2026',
        '<i class="fas fa-map-marker-alt text-success me-1"></i> Katsina State, Nigeria',
        '<i class="fas fa-seedling text-success me-1"></i> 150 Seedlings Planted',
        '<i class="fas fa-handshake text-success me-1"></i> Partner: AYINET'
    ],
    hero_title="GNEP and AYINET Plant 150 Economic Tree Seedlings in Katsina State",
    hero_lead="Fostering community-led land restoration, indigenous species adaptation, and economic resilience across northern Nigeria's arid frontier.",
    featured_img="assets/real/hero-tree-planting.webp",
    featured_caption="Community members and youth leaders during the economic tree planting drive in Katsina State.",
    body_html=tree_body,
    sidebar_facts=[
        ("fas fa-seedling", "Total Seedlings", "150 Economic Trees"),
        ("fas fa-calendar-alt", "Timeline", "2025 &ndash; 2026"),
        ("fas fa-map-marker-alt", "Location", "Katsina State, Nigeria"),
        ("fas fa-handshake", "Collaborating Partner", "African Youth Initiative Network (AYINET)"),
        ("fas fa-shield-alt", "Focus Area", "Nature &amp; Ecosystem Restoration")
    ],
    related_links=[
        ("cso-policy-workshop.html", "fas fa-chalkboard-teacher", "CSO Policy & Advocacy Training", "Trained 20 civil society representatives"),
        ("communicating-environmental-issues.html", "fas fa-bullhorn", "Why Storytelling Matters", "Civil society environmental advocacy"),
        ("youth-environmental-action.html", "fas fa-users", "Youth-Led Environmental Action", "Grassroots climate clubs in schools")
    ]
)

with open(os.path.join(BASE_DIR, "tree-planting-150-seedlings.html"), "w", encoding="utf-8") as f:
    f.write(tree_page_html)
print("Created tree-planting-150-seedlings.html")


# =========================================================================
# 2. BUILD: communicating-environmental-issues.html
# =========================================================================
comm_paras = get_docx_paragraphs("Communicating Environmental Issues.docx")
comm_body = ""
for p in comm_paras[2:]: # skip header and author line
    if len(p) < 80 and not p.endswith("."):
        comm_body += f"<h2>{p}</h2>\n"
    elif "storytelling" in p.lower() and len(p) < 200:
        comm_body += f'<div class="article-quote-box">&ldquo;{p}&rdquo;</div>\n'
    else:
        comm_body += f"<p>{p}</p>\n"

# Add images
comm_body += """
<div class="my-4 rounded-3 overflow-hidden shadow-sm border">
    <img src="assets/real/storytelling-speaker.webp" alt="Speaker at the Storytelling & Persuasive Communication Workshop" class="img-fluid w-100" style="object-fit: cover;">
    <div class="p-2 bg-light border-top small text-muted text-center">
        Session facilitator illustrating narrative structure and community framing techniques.
    </div>
</div>
"""

comm_page_html = render_article_page(
    meta_title="Communicating Environmental Issues: Why Storytelling Matters | GNEP Africa",
    meta_desc="An editorial analysis by Maryam DAUDA on the power of storytelling and persuasive communication for African environmental advocacy.",
    og_image="assets/real/storytelling-speaker.webp",
    breadcrumb_title="Environmental Storytelling",
    hero_badges=[
        '<i class="fas fa-user-edit text-success me-1"></i> By Maryam DAUDA',
        '<i class="fas fa-calendar-alt text-success me-1"></i> 2025–2026',
        '<i class="fas fa-bullhorn text-success me-1"></i> Environmental Advocacy',
        '<i class="fas fa-book-reader text-success me-1"></i> Research & Insights'
    ],
    hero_title="Communicating Environmental Issues: Why Storytelling Matters for Civil Society",
    hero_lead="Translating technical environmental reports, climate models, and statistics into compelling human stories that inspire community ownership and political accountability.",
    featured_img="assets/real/storytelling-speaker.webp",
    featured_caption="GNEP Storytelling and Persuasive Communication Workshop for CSOs in Katsina State.",
    body_html=comm_body,
    sidebar_facts=[
        ("fas fa-user-edit", "Author", "Maryam DAUDA"),
        ("fas fa-tag", "Theme", "Advocacy Communication &amp; Storytelling"),
        ("fas fa-map-marker-alt", "Region", "Katsina State, Nigeria"),
        ("fas fa-landmark", "Organization", "Global Nature and Environmental Partnership (GNEP)")
    ],
    related_links=[
        ("cso-policy-workshop.html", "fas fa-chalkboard-teacher", "CSO Policy & Advocacy Training", "Trained 20 civil society representatives"),
        ("tree-planting-150-seedlings.html", "fas fa-seedling", "150 Economic Tree Seedlings", "Restoration drive with AYINET"),
        ("turning-research-into-action.html", "fas fa-file-contract", "Turning Research into Action", "Evidence-based policy engagement")
    ]
)

with open(os.path.join(BASE_DIR, "communicating-environmental-issues.html"), "w", encoding="utf-8") as f:
    f.write(comm_page_html)
print("Created communicating-environmental-issues.html")


# =========================================================================
# 3. BUILD: turning-research-into-action.html
# =========================================================================
turn_paras = get_docx_paragraphs("Turning Research into Action.docx")
turn_body = ""
for p in turn_paras[2:]:
    if len(p) < 80 and not p.endswith("."):
        turn_body += f"<h2>{p}</h2>\n"
    elif "policy" in p.lower() and len(p) < 180 and "evidence" in p.lower():
        turn_body += f'<div class="article-quote-box">&ldquo;{p}&rdquo;</div>\n'
    else:
        turn_body += f"<p>{p}</p>\n"

turn_page_html = render_article_page(
    meta_title="Turning Research into Action: Strengthening Evidence-Based Policy | GNEP Africa",
    meta_desc="How GNEP bridges the gap between academic climate research, policy design, and community-led execution in Nigeria.",
    og_image="assets/real/policy-brief-research.webp",
    breadcrumb_title="Turning Research into Action",
    hero_badges=[
        '<i class="fas fa-university text-success me-1"></i> Policy &amp; Research Series',
        '<i class="fas fa-calendar-alt text-success me-1"></i> 2025–2026',
        '<i class="fas fa-balance-scale text-success me-1"></i> Environmental Governance',
        '<i class="fas fa-globe-africa text-success me-1"></i> Pan-African Outlook'
    ],
    hero_title="Turning Research into Action: Strengthening Evidence-Based Policy Engagement",
    hero_lead="Addressing climate challenges requires moving beyond good intentions to institutional delivery, rigorous data synthesis, and actionable policy briefs.",
    featured_img="assets/real/policy-brief-research.webp",
    featured_caption="Policy and institutional research participants analyzing climate governance evidence in Katsina.",
    body_html=turn_body,
    sidebar_facts=[
        ("fas fa-landmark", "Publisher", "GNEP Africa Policy Practice Series"),
        ("fas fa-tag", "Focus", "Evidence Synthesis &amp; Public Administration"),
        ("fas fa-search", "Methodology", "Mixed-methods policy analysis &amp; local indicators"),
        ("fas fa-graduation-cap", "Lead Research", "Mohammed Labaran Sani &amp; GNEP Team")
    ],
    related_links=[
        ("cso-policy-workshop.html", "fas fa-chalkboard-teacher", "CSO Policy & Advocacy Training", "Trained 20 civil society representatives"),
        ("tree-planting-150-seedlings.html", "fas fa-seedling", "150 Economic Tree Seedlings", "Restoration drive with AYINET"),
        ("nigeria-heat-emergency-policy-brief.html", "fas fa-fire-alt", "Nigeria Heat Emergency Brief", "Super El Niño heat preparedness")
    ]
)

with open(os.path.join(BASE_DIR, "turning-research-into-action.html"), "w", encoding="utf-8") as f:
    f.write(turn_page_html)
print("Created turning-research-into-action.html")


# =========================================================================
# 4. BUILD: youth-environmental-action.html
# =========================================================================
youth_paras = get_docx_paragraphs("Youth.docx")
youth_body = ""
for p in youth_paras[2:]:
    if len(p) < 80 and not p.endswith("."):
        youth_body += f"<h2>{p}</h2>\n"
    elif "youth" in p.lower() and len(p) < 180 and "lead" in p.lower():
        youth_body += f'<div class="article-quote-box">&ldquo;{p}&rdquo;</div>\n'
    else:
        youth_body += f"<p>{p}</p>\n"

youth_body += """
<div class="my-4 rounded-3 overflow-hidden shadow-sm border">
    <img src="assets/real/schools-tree-planting.webp" alt="Students and youth in GNEP climate clubs initiative" class="img-fluid w-100" style="object-fit: cover;">
    <div class="p-2 bg-light border-top small text-muted text-center">
        Secondary school students participating in GNEP Climate Clubs and green education activities.
    </div>
</div>
"""

youth_page_html = render_article_page(
    meta_title="Youth-Led Environmental Action: Building Local Capacity | GNEP Africa",
    meta_desc="Empowering the next generation of African environmental leaders through Climate Clubs, eco-literacy, and community green skills.",
    og_image="assets/real/schools-tree-planting.webp",
    breadcrumb_title="Youth-Led Action",
    hero_badges=[
        '<i class="fas fa-users text-success me-1"></i> Youth Empowerment',
        '<i class="fas fa-calendar-alt text-success me-1"></i> Ongoing Initiative',
        '<i class="fas fa-school text-success me-1"></i> Climate Clubs in Schools',
        '<i class="fas fa-seedling text-success me-1"></i> Green Skills'
    ],
    hero_title="Youth-Led Environmental Action: Building Local Capacity for Sustainable Development",
    hero_lead="Young people are not merely future beneficiaries; they are active architects of climate resilience and ecological restoration in their communities.",
    featured_img="assets/real/schools-tree-planting.webp",
    featured_caption="Youth and secondary school students participating in GNEP's Katsina State climate initiative.",
    body_html=youth_body,
    sidebar_facts=[
        ("fas fa-users", "Target Group", "Secondary School Students &amp; Youth CSOs"),
        ("fas fa-school", "Key Program", "Climate Clubs in Schools"),
        ("fas fa-map-marker-alt", "Location", "Katsina State, Nigeria"),
        ("fas fa-hand-holding-heart", "Model", "Experiential ecological literacy &amp; seed nurseries")
    ],
    related_links=[
        ("tree-planting-150-seedlings.html", "fas fa-seedling", "150 Economic Tree Seedlings", "Restoration drive with AYINET"),
        ("cso-policy-workshop.html", "fas fa-chalkboard-teacher", "CSO Policy & Advocacy Training", "Trained 20 civil society representatives"),
        ("founder.html", "fas fa-user-circle", "Mohammed Labaran Sani", "Founder & Lead profile")
    ]
)

with open(os.path.join(BASE_DIR, "youth-environmental-action.html"), "w", encoding="utf-8") as f:
    f.write(youth_page_html)
print("Created youth-environmental-action.html")


# =========================================================================
# 5. BUILD: nigeria-heat-emergency-policy-brief.html
# =========================================================================
heat_paras = get_docx_paragraphs("Nigeria_Heat_Emergency_Policy_Brief.docx")
heat_body = ""
for p in heat_paras[:35]: # take first key chapters
    if len(p) < 80 and not p.endswith("."):
        heat_body += f"<h2>{p}</h2>\n"
    elif "lives" in p.lower() or "emergency" in p.lower() and len(p) < 180:
        heat_body += f'<div class="article-quote-box">&ldquo;{p}&rdquo;</div>\n'
    else:
        heat_body += f"<p>{p}</p>\n"

heat_page_html = render_article_page(
    meta_title="Policy Brief: 31,400 Lives at Risk? Nigeria's Heat Emergency | GNEP Africa",
    meta_desc="Urgent Policy Brief: Super El Niño heat-health preparedness in Nigeria for September 2026 to February 2027.",
    og_image="assets/real/nigeria-heat-emergency-crisis.webp",
    breadcrumb_title="Heat Emergency Policy Brief",
    hero_badges=[
        '<i class="fas fa-exclamation-triangle text-warning me-1"></i> URGENT POLICY BRIEF',
        '<i class="fas fa-calendar-alt text-success me-1"></i> Sep 2026 &ndash; Feb 2027',
        '<i class="fas fa-shield-virus text-danger me-1"></i> Public Health Emergency',
        '<i class="fas fa-file-alt text-success me-1"></i> Evidence Synthesis'
    ],
    hero_title="31,400 Lives at Risk? Nigeria's Race Against Super El Niño",
    hero_lead="Critical institutional and community heat-health preparedness recommendations for vulnerable populations across northern Nigeria and the Sahel.",
    featured_img="assets/real/nigeria-heat-emergency-crisis.webp",
    featured_caption="Official crisis briefing graphic: Nigeria's Super El Niño Heat Emergency Framework.",
    body_html=heat_body,
    sidebar_facts=[
        ("fas fa-file-medical-alt", "Document Type", "Urgent Policy Brief"),
        ("fas fa-users-slash", "At-Risk Population", "Over 31,400 vulnerable citizens"),
        ("fas fa-clock", "Window of Action", "September 2026 &ndash; February 2027"),
        ("fas fa-landmark", "Institutional Scope", "Federal Ministry of Health, SUBEB &amp; CSOs")
    ],
    related_links=[
        ("cso-policy-workshop.html", "fas fa-chalkboard-teacher", "CSO Policy & Advocacy Training", "Trained 20 civil society representatives"),
        ("turning-research-into-action.html", "fas fa-file-contract", "Turning Research into Action", "Evidence-based policy engagement"),
        ("founder.html", "fas fa-user-circle", "Mohammed Labaran Sani", "Founder & Lead profile")
    ]
)

with open(os.path.join(BASE_DIR, "nigeria-heat-emergency-policy-brief.html"), "w", encoding="utf-8") as f:
    f.write(heat_page_html)
print("Created nigeria-heat-emergency-policy-brief.html")


# =========================================================================
# 6. UPDATE LINKS IN index.html & events.html
# =========================================================================

# Update index.html
index_file = os.path.join(BASE_DIR, "index.html")
with open(index_file, "r", encoding="utf-8") as f:
    idx_content = f.read()

# Make Tree Planting card link to tree-planting-150-seedlings.html
idx_content = idx_content.replace(
    '<a href="#updates" class="update-link">Read field notes <i class="fas fa-arrow-right ms-1" aria-hidden="true"></i></a>',
    '<a href="tree-planting-150-seedlings.html" class="update-link">Read field story &amp; results <i class="fas fa-arrow-right ms-1" aria-hidden="true"></i></a>'
)
# Wrap the tree planting image in a link
idx_content = idx_content.replace(
    '<img src="assets/real/tree-planting-action.webp" alt="Tree seedling being planted in soil" loading="lazy" width="600" height="350">',
    '<a href="tree-planting-150-seedlings.html"><img src="assets/real/tree-planting-action.webp" alt="Tree seedling being planted in soil" loading="lazy" width="600" height="350"></a>'
)

# Card 3 (SUBEB / Institutional)
idx_content = idx_content.replace(
    '<a href="#updates" class="update-link">Read participation record <i class="fas fa-arrow-right ms-1" aria-hidden="true"></i></a>',
    '<a href="events.html" class="update-link">Read participation record <i class="fas fa-arrow-right ms-1" aria-hidden="true"></i></a>'
)

with open(index_file, "w", encoding="utf-8") as f:
    f.write(idx_content)
print("Updated article links in index.html")


# Update events.html
events_file = os.path.join(BASE_DIR, "events.html")
with open(events_file, "r", encoding="utf-8") as f:
    ev_content = f.read()

# Make Card 2 (Tree Planting) link to tree-planting-150-seedlings.html
old_card2_needle = '<h3 class="gnep-activity-title">150 Economic Tree Seedlings Planted in Katsina State</h3>'
if old_card2_needle in ev_content and 'tree-planting-150-seedlings.html' not in ev_content:
    new_card2_title = '<h3 class="gnep-activity-title"><a href="tree-planting-150-seedlings.html" class="text-dark text-decoration-none">150 Economic Tree Seedlings Planted in Katsina State</a></h3>'
    ev_content = ev_content.replace(old_card2_needle, new_card2_title)
    
    # Add read story button before footer in Card 2
    c2_footer_needle = '<span class="gnep-photo-credit">Photo credit: GNEP / AYINET</span>'
    c2_button = """<a href="tree-planting-150-seedlings.html" class="btn btn-sm btn-outline-success w-100 mb-2">
                                    <i class="fas fa-seedling me-1"></i> Read Full Restoration Story
                                </a>\n                                    """
    ev_content = ev_content.replace(c2_footer_needle, c2_button + c2_footer_needle, 1)

# Card 3 (Storytelling Workshop)
old_card3_needle = '<h3 class="gnep-activity-title">Storytelling &amp; Persuasive Communication Workshop for CSOs</h3>'
if old_card3_needle in ev_content and 'communicating-environmental-issues.html' not in ev_content:
    new_card3_title = '<h3 class="gnep-activity-title"><a href="communicating-environmental-issues.html" class="text-dark text-decoration-none">Storytelling &amp; Persuasive Communication Workshop for CSOs</a></h3>'
    ev_content = ev_content.replace(old_card3_needle, new_card3_title)
    
    c3_footer_needle = '<span class="gnep-photo-credit">Photo credit: GNEP</span>'
    c3_button = """<a href="communicating-environmental-issues.html" class="btn btn-sm btn-outline-success w-100 mb-2">
                                    <i class="fas fa-bullhorn me-1"></i> Read Article: Why Storytelling Matters
                                </a>\n                                    """
    ev_content = ev_content.replace(c3_footer_needle, c3_button + c3_footer_needle, 1)

# Card 5 (Climate Clubs in Schools)
old_card5_needle = '<h3 class="gnep-activity-title">Climate Clubs in Schools — Katsina State</h3>'
if old_card5_needle in ev_content and 'youth-environmental-action.html' not in ev_content:
    new_card5_title = '<h3 class="gnep-activity-title"><a href="youth-environmental-action.html" class="text-dark text-decoration-none">Climate Clubs in Schools — Katsina State</a></h3>'
    ev_content = ev_content.replace(old_card5_needle, new_card5_title)
    
    c5_footer_needle = '<span class="gnep-photo-credit">Photo credit: GNEP / AYINET</span>'
    # notice this is the 2nd occurrence of AYINET photo credit
    parts = ev_content.split(c5_footer_needle)
    if len(parts) >= 2:
        c5_button = """<a href="youth-environmental-action.html" class="btn btn-sm btn-outline-success w-100 mb-2">
                                    <i class="fas fa-users me-1"></i> Read Youth-Led Action Article
                                </a>\n                                    """
        ev_content = parts[0] + c5_footer_needle + parts[1] + c5_button + c5_footer_needle + "".join(parts[2:])

with open(events_file, "w", encoding="utf-8") as f:
    f.write(ev_content)
print("Updated article links in events.html")

print("ALL ARTICLES BUILT AND LINKED SUCCESSFULLY!")
