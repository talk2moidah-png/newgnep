# -*- coding: utf-8 -*-
"""
Full builder for Mohammed Labaran Sani's Biography system:
1. Custom CSS in css/gnep.css
2. Modal markup for index.html and about.html
3. Standalone founder.html page
4. Card updates in index.html and about.html
"""

import os
import re

BASE_DIR = r"C:\Users\SURFACE\.gemini\antigravity\scratch\youth-ngo-website\nature-website-template"

# 1. Custom CSS rules for founder modal & profile
FOUNDER_CSS = """
/* ==========================================================================
   FOUNDER BIOGRAPHY MODAL & PROFILE STYLES
   ========================================================================== */
.gnep-bio-modal .modal-content {
    border-radius: 16px;
    overflow: hidden;
    border: 1px solid rgba(16, 185, 129, 0.2);
    box-shadow: 0 25px 60px rgba(11, 37, 22, 0.35);
    background: #ffffff;
}
.gnep-bio-modal .modal-header {
    background: linear-gradient(135deg, #0B2516 0%, #153E26 60%, #1A4D2E 100%) !important;
    border-bottom: 2px solid #10B981;
    padding: 1.25rem 2rem;
}
.gnep-bio-modal .modal-body {
    padding: 2.25rem;
    color: #2D3748;
    background: #FAFCF9;
}
.gnep-founder-portrait-frame {
    position: relative;
    border-radius: 14px;
    overflow: hidden;
    box-shadow: 0 12px 30px rgba(11, 37, 22, 0.18);
    border: 3px solid #ffffff;
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}
.gnep-founder-portrait-frame:hover {
    transform: translateY(-4px);
    box-shadow: 0 18px 40px rgba(11, 37, 22, 0.25);
}
.gnep-founder-portrait-img {
    width: 100%;
    height: auto;
    object-fit: cover;
    display: block;
}
.founder-badge-pauwes {
    display: inline-flex;
    align-items: center;
    gap: 0.4rem;
    background: #E8F5E9;
    color: #1B5E20;
    font-size: 0.78rem;
    font-weight: 700;
    padding: 0.35rem 0.75rem;
    border-radius: 50px;
    border: 1px solid #C8E6C9;
}
.founder-meta-box {
    background: #ffffff;
    border-radius: 12px;
    padding: 1.25rem;
    border: 1px solid #E2E8F0;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
    margin-bottom: 1.25rem;
}
.founder-meta-title {
    font-size: 0.75rem;
    text-transform: uppercase;
    letter-spacing: 0.08em;
    font-weight: 700;
    color: #718096;
    margin-bottom: 0.5rem;
}
.founder-meta-item {
    font-size: 0.88rem;
    color: #2D3748;
    margin-bottom: 0.6rem;
    display: flex;
    align-items: flex-start;
    gap: 0.6rem;
}
.founder-meta-item:last-child {
    margin-bottom: 0;
}
.founder-meta-item i {
    color: #15803D;
    margin-top: 3px;
    flex-shrink: 0;
}
.founder-tab-nav {
    display: flex;
    flex-wrap: wrap;
    gap: 0.5rem;
    border-bottom: 2px solid #E2E8F0;
    padding-bottom: 0.75rem;
    margin-bottom: 1.75rem;
}
.founder-tab-nav .nav-link {
    color: #4A5568;
    font-weight: 600;
    font-size: 0.9rem;
    padding: 0.5rem 1rem;
    border-radius: 6px;
    border: none;
    background: transparent;
    transition: all 0.2s ease;
}
.founder-tab-nav .nav-link:hover {
    color: #15803D;
    background: #EDF7ED;
}
.founder-tab-nav .nav-link.active {
    color: #ffffff;
    background: #15803D;
}
.bio-lead-quote {
    font-family: 'Newsreader', Georgia, serif;
    font-style: italic;
    font-size: 1.15rem;
    line-height: 1.6;
    color: #1A365D;
    border-left: 4px solid #10B981;
    padding-left: 1.25rem;
    margin: 1.25rem 0;
    background: #F0FDF4;
    padding-top: 0.85rem;
    padding-bottom: 0.85rem;
    border-radius: 0 8px 8px 0;
}
.publication-card {
    background: #ffffff;
    border-radius: 10px;
    padding: 1.25rem 1.5rem;
    border-left: 4px solid #15803D;
    box-shadow: 0 2px 8px rgba(0,0,0,0.05);
    margin-bottom: 1rem;
    transition: transform 0.2s ease, box-shadow 0.2s ease;
}
.publication-card:hover {
    transform: translateX(4px);
    box-shadow: 0 6px 16px rgba(0,0,0,0.08);
}
.publication-status-badge {
    font-size: 0.7rem;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.05em;
    padding: 0.2rem 0.6rem;
    border-radius: 4px;
}
.pub-review { background: #FEF3C7; color: #92400E; }
.pub-published { background: #D1FAE5; color: #065F46; }
.pub-conference { background: #E0E7FF; color: #3730A3; }
.pub-training { background: #F3E8FF; color: #6B21A8; }

.founder-card-interactive {
    cursor: pointer;
    transition: transform 0.3s cubic-bezier(0.165, 0.84, 0.44, 1), box-shadow 0.3s ease;
    position: relative;
}
.founder-card-interactive:hover {
    transform: translateY(-6px);
    box-shadow: 0 16px 36px rgba(11, 37, 22, 0.16) !important;
}
.founder-card-cta-badge {
    position: absolute;
    top: 14px;
    right: 14px;
    background: #10B981;
    color: #ffffff;
    font-size: 0.75rem;
    font-weight: 700;
    padding: 0.3rem 0.75rem;
    border-radius: 20px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.15);
    pointer-events: none;
    display: inline-flex;
    align-items: center;
    gap: 0.35rem;
}
"""

css_path = os.path.join(BASE_DIR, "css", "gnep.css")
with open(css_path, "r", encoding="utf-8") as f:
    existing_css = f.read()

if "FOUNDER BIOGRAPHY MODAL & PROFILE STYLES" not in existing_css:
    with open(css_path, "a", encoding="utf-8") as f:
        f.write("\n" + FOUNDER_CSS + "\n")
    print("Appended founder CSS to css/gnep.css")
else:
    print("Founder CSS already present in css/gnep.css")

# 2. Build Modal Content HTML
MODAL_HTML = """
<!-- ==========================================================================
     FOUNDER BIOGRAPHY & RESEARCH MODAL
     ========================================================================== -->
<div class="modal fade gnep-bio-modal" id="founderBioModal" tabindex="-1" aria-labelledby="founderBioModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-xl">
        <div class="modal-content border-0 shadow-lg">
            <!-- Modal Header -->
            <div class="modal-header text-white px-4 py-3 border-0">
                <div class="d-flex align-items-center gap-3">
                    <img src="assets/real/founder-mohammed-labaran-sani.webp" alt="Mohammed Labaran Sani" class="rounded-circle border border-2 border-white" width="46" height="46" style="object-fit: cover; aspect-ratio: 1/1;">
                    <div>
                        <h3 class="modal-title h5 fw-bold text-white mb-0" id="founderBioModalLabel">Mohammed Labaran Sani</h3>
                        <span class="small" style="color: #BFD3C7;">Founder &amp; Project Lead, GNEP Africa &bull; MSc Climate Change Policy Candidate (PAUWES)</span>
                    </div>
                </div>
                <div class="d-flex align-items-center gap-2">
                    <a href="founder.html" target="_blank" class="btn btn-sm btn-outline-light d-none d-sm-inline-flex align-items-center gap-1" title="Open in dedicated page">
                        <i class="fas fa-external-link-alt" aria-hidden="true"></i> Standalone Page
                    </a>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
            </div>

            <!-- Modal Body -->
            <div class="modal-body p-3 p-md-4 p-lg-5">
                <div class="row g-4">
                    <!-- Left Column: Portrait & Credentials -->
                    <div class="col-lg-4">
                        <div class="gnep-founder-portrait-frame mb-3">
                            <img src="assets/real/founder-mohammed-labaran-sani.webp" alt="Mohammed Labaran Sani portrait" class="gnep-founder-portrait-img">
                        </div>
                        
                        <div class="text-center mb-3">
                            <span class="founder-badge-pauwes mb-2">
                                <i class="fas fa-graduation-cap text-success" aria-hidden="true"></i> PAUWES Scholar (MSc 2027)
                            </span>
                            <h4 class="h5 fw-bold text-dark mb-1">Mohammed Labaran Sani</h4>
                            <p class="small text-muted mb-2">Climate Policy Researcher &bull; Social Entrepreneur</p>
                            <div class="d-flex justify-content-center gap-2">
                                <a href="https://www.linkedin.com/company/global-nature-environmental-partnership/" target="_blank" rel="noopener noreferrer" class="btn btn-sm btn-outline-success">
                                    <i class="fab fa-linkedin me-1" aria-hidden="true"></i> LinkedIn
                                </a>
                                <a href="mailto:gnep.partnership@gmail.com?subject=Partnership%20Inquiry%20for%20Mohammed%20Labaran%20Sani" class="btn btn-sm btn-success">
                                    <i class="fas fa-envelope me-1" aria-hidden="true"></i> Contact
                                </a>
                            </div>
                        </div>

                        <!-- Credentials Box -->
                        <div class="founder-meta-box">
                            <div class="founder-meta-title">Academic Qualifications</div>
                            <div class="founder-meta-item">
                                <i class="fas fa-university" aria-hidden="true"></i>
                                <div>
                                    <strong>MSc in Climate Change Policy</strong><br>
                                    <span class="small text-muted">Pan-African University (PAUWES), Algeria (Exp. Aug 2027)</span>
                                </div>
                            </div>
                            <div class="founder-meta-item">
                                <i class="fas fa-scroll" aria-hidden="true"></i>
                                <div>
                                    <strong>BSc in Political Science</strong><br>
                                    <span class="small text-muted">Umaru Musa Yar'adua University, Katsina (2021)</span>
                                </div>
                            </div>
                            <div class="founder-meta-item">
                                <i class="fas fa-certificate" aria-hidden="true"></i>
                                <div>
                                    <strong>Diploma in Office Technology &amp; Mgmt</strong><br>
                                    <span class="small text-muted">Hassan Usman Katsina Polytechnic (2015)</span>
                                </div>
                            </div>
                        </div>

                        <!-- Experience Highlights Box -->
                        <div class="founder-meta-box">
                            <div class="founder-meta-title">Career Milestones</div>
                            <div class="founder-meta-item">
                                <i class="fas fa-globe-africa" aria-hidden="true"></i>
                                <div>
                                    <strong>Founder &amp; Project Lead</strong><br>
                                    <span class="small text-muted">GNEP Africa (Jan 2025 &ndash; Present)</span>
                                </div>
                            </div>
                            <div class="founder-meta-item">
                                <i class="fas fa-users-cog" aria-hidden="true"></i>
                                <div>
                                    <strong>Soft-Skills &amp; Enterprise Trainer</strong><br>
                                    <span class="small text-muted">Jobberman Nigeria (12,000+ women &amp; youth trained)</span>
                                </div>
                            </div>
                            <div class="founder-meta-item">
                                <i class="fas fa-database" aria-hidden="true"></i>
                                <div>
                                    <strong>Enumerator &amp; Technical Support</strong><br>
                                    <span class="small text-muted">eHealth Africa (Public Health Digitization, 2024)</span>
                                </div>
                            </div>
                            <div class="founder-meta-item">
                                <i class="fas fa-chalkboard-teacher" aria-hidden="true"></i>
                                <div>
                                    <strong>Secondary Educator</strong><br>
                                    <span class="small text-muted">Shahrab Int'l School, Katsina (2021 &ndash; 2024)</span>
                                </div>
                            </div>
                        </div>

                        <!-- Research Affiliations -->
                        <div class="founder-meta-box">
                            <div class="founder-meta-title">Research &amp; Fellowships</div>
                            <div class="founder-meta-item">
                                <i class="fas fa-book-reader" aria-hidden="true"></i>
                                <div>
                                    <strong>Research Trainee</strong><br>
                                    <span class="small text-muted">South African Institute of International Affairs (SAIIA), Johannesburg (Apr 2026)</span>
                                </div>
                            </div>
                            <div class="founder-meta-item">
                                <i class="fas fa-award" aria-hidden="true"></i>
                                <div>
                                    <strong>Outstanding Student Leader</strong><br>
                                    <span class="small text-muted">UMYU Dept. of Political Science (2021)</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Right Column: Structured Biography Chapters -->
                    <div class="col-lg-8">
                        <!-- Navigation Tabs inside Modal -->
                        <ul class="nav nav-pills founder-tab-nav" id="founderTab" role="tablist">
                            <li class="nav-item" role="presentation">
                                <button class="nav-link active" id="bio-overview-tab" data-bs-toggle="pill" data-bs-target="#bio-overview" type="button" role="tab" aria-controls="bio-overview" aria-selected="true">
                                    <i class="fas fa-user me-1" aria-hidden="true"></i> Overview
                                </button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="bio-academic-tab" data-bs-toggle="pill" data-bs-target="#bio-academic" type="button" role="tab" aria-controls="bio-academic" aria-selected="false">
                                    <i class="fas fa-graduation-cap me-1" aria-hidden="true"></i> Academic Path
                                </button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="bio-career-tab" data-bs-toggle="pill" data-bs-target="#bio-career" type="button" role="tab" aria-controls="bio-career" aria-selected="false">
                                    <i class="fas fa-briefcase me-1" aria-hidden="true"></i> Experience &amp; Impact
                                </button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="bio-gnep-tab" data-bs-toggle="pill" data-bs-target="#bio-gnep" type="button" role="tab" aria-controls="bio-gnep" aria-selected="false">
                                    <i class="fas fa-seedling me-1" aria-hidden="true"></i> GNEP Founding
                                </button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="bio-research-tab" data-bs-toggle="pill" data-bs-target="#bio-research" type="button" role="tab" aria-controls="bio-research" aria-selected="false">
                                    <i class="fas fa-file-alt me-1" aria-hidden="true"></i> Research &amp; Papers
                                </button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="bio-vision-tab" data-bs-toggle="pill" data-bs-target="#bio-vision" type="button" role="tab" aria-controls="bio-vision" aria-selected="false">
                                    <i class="fas fa-compass me-1" aria-hidden="true"></i> Vision for Africa
                                </button>
                            </li>
                        </ul>

                        <!-- Tab Panes -->
                        <div class="tab-content" id="founderTabContent">
                            <!-- Tab 1: Overview -->
                            <div class="tab-pane fade show active" id="bio-overview" role="tabpanel" aria-labelledby="bio-overview-tab">
                                <span class="badge bg-success bg-opacity-10 text-success fw-bold text-uppercase px-2 py-1 mb-2">Executive Biography</span>
                                <h3 class="h4 fw-bold text-dark mb-3">Mohammed Labaran Sani: A Journey Through Governance, Research and Climate Action</h3>
                                
                                <p class="lead text-dark" style="font-size: 1.05rem; line-height: 1.7;">
                                    Mohammed Labaran Sani is a Nigerian climate policy researcher, development practitioner, and social entrepreneur whose work focuses on climate governance, adaptation finance, institutional effectiveness, and community-led environmental action in Africa.
                                </p>
                                
                                <p>
                                    With an academic foundation in Political Science and postgraduate training in Climate Change Policy, he works at the intersection of research, public policy, and practical development. His professional journey spans education, public health programme support, entrepreneurship training, environmental advocacy, and youth leadership, reflecting a sustained interest in how institutions can translate policy commitments into meaningful outcomes for communities.
                                </p>

                                <div class="bio-lead-quote">
                                    &ldquo;Ambitious climate commitments mean little if they fail to produce corresponding improvements in the lives of the communities they are intended to protect. Our responsibility is to turn policy ambition into institutional delivery.&rdquo;
                                </div>

                                <p>
                                    He is the Founder and Project Lead of the <strong>Global Nature and Environmental Partnership (GNEP)</strong>, a youth-led environmental initiative established to advance climate literacy, renewable energy awareness, sustainable livelihoods, and evidence-informed environmental governance. Through GNEP, he seeks to strengthen the participation of young people and civil society organisations in climate policy processes, particularly in underserved communities in Nigeria.
                                </p>

                                <p>
                                    Currently pursuing a Master of Science in Climate Change Policy at the <strong>Pan-African University Institute for Water and Energy Sciences, including Climate Change (PAUWES)</strong>, in Algeria, Sani is developing an interdisciplinary approach to African development challenges. His work connects political institutions, public policy, environmental sustainability, and the economic conditions that shape communities' capacity to respond to climate change.
                                </p>
                            </div>

                            <!-- Tab 2: Academic Foundations -->
                            <div class="tab-pane fade" id="bio-academic" role="tabpanel" aria-labelledby="bio-academic-tab">
                                <span class="badge bg-success bg-opacity-10 text-success fw-bold text-uppercase px-2 py-1 mb-2">Academic Journey</span>
                                <h3 class="h4 fw-bold text-dark mb-3">Academic Foundations and Intellectual Development</h3>

                                <p>
                                    Sani's academic development began with an interest in political institutions, public administration, regional integration, and the processes through which governments make and implement decisions.
                                </p>

                                <div class="card border-0 bg-light p-3 mb-3 rounded-3">
                                    <h4 class="h6 fw-bold text-dark mb-1"><i class="fas fa-graduation-cap text-success me-2" aria-hidden="true"></i>Hassan Usman Katsina Polytechnic (2015)</h4>
                                    <p class="small text-muted mb-0">Diploma in Office Technology and Management Studies. The programme provided an early foundation in administration, organisation, communication, and information management, skills that would later support his work in programme coordination and institutional engagement.</p>
                                </div>

                                <div class="card border-0 bg-light p-3 mb-3 rounded-3">
                                    <h4 class="h6 fw-bold text-dark mb-1"><i class="fas fa-university text-success me-2" aria-hidden="true"></i>Umaru Musa Yar'adua University (2021)</h4>
                                    <p class="small text-muted mb-0">Bachelor of Science in Political Science. His undergraduate studies examined the structures of political authority, public policy, international relations, political economy, development administration, and the relationship between institutions and society.</p>
                                </div>

                                <h4 class="h6 fw-bold text-dark mt-4 mb-2">Undergraduate Thesis: Regional Integration &amp; The African Union</h4>
                                <p>
                                    His undergraduate research focused on <em>The African Union (AU), Regional Integration, and the Challenges of Globalisation in the Twenty-First Century</em>. The study examined regional integration as a pathway for African cooperation and development while considering the challenges that shape the continent's position in an increasingly interconnected global system. The thesis, subsequently made available through Zenodo, reflects his early engagement with questions concerning African institutions, regional cooperation, and the implementation of collective development ambitions.
                                </p>

                                <div class="card border-0 bg-light p-3 mb-3 rounded-3">
                                    <h4 class="h6 fw-bold text-dark mb-1"><i class="fas fa-globe-africa text-success me-2" aria-hidden="true"></i>PAUWES &ndash; Pan-African University, Algeria (Expected August 2027)</h4>
                                    <p class="small text-muted mb-0">MSc in Climate Change Policy at PAUWES in Tlemcen, Algeria. His postgraduate studies extend his earlier interest in public policy into environmental governance, climate adaptation, mitigation planning, climate finance, and sustainable energy transitions. Through this training, he is developing the capacity to examine climate change as both an environmental challenge and a governance issue shaped by institutional performance, financing arrangements, and policy choices.</p>
                                </div>

                                <p class="text-muted small">
                                    His academic direction is increasingly centred on a fundamental question: why do ambitious climate commitments sometimes fail to produce corresponding improvements in the lives of the communities they are intended to protect? By combining political science with climate policy, Sani examines the institutional bottlenecks, financing gaps, and implementation challenges that complicate climate action across Africa.
                                </p>
                            </div>

                            <!-- Tab 3: Professional Experience -->
                            <div class="tab-pane fade" id="bio-career" role="tabpanel" aria-labelledby="bio-career-tab">
                                <span class="badge bg-success bg-opacity-10 text-success fw-bold text-uppercase px-2 py-1 mb-2">Field &amp; Industry Impact</span>
                                <h3 class="h4 fw-bold text-dark mb-3">Professional Experience and Community Engagement</h3>

                                <p>
                                    Sani's professional experience spans education, public health, entrepreneurship development, and environmental action. These roles provided practical exposure to community realities, organisational coordination, and the challenges of programme delivery.
                                </p>

                                <div class="row g-3 mb-4">
                                    <div class="col-md-6">
                                        <div class="card h-100 p-3 border-0 shadow-sm" style="background: #F0FDF4;">
                                            <div class="fw-bold text-success mb-1"><i class="fas fa-users me-2" aria-hidden="true"></i>12,000+ Market Women &amp; Youth</div>
                                            <div class="h6 fw-bold text-dark mb-1">Jobberman Nigeria (2023&ndash;2024)</div>
                                            <p class="small text-muted mb-0">As a soft-skills trainer on the Mastercard Foundation-supported initiative across three northern Nigerian states, Sani delivered foundational workplace, entrepreneurship, and financial literacy training, improving economic agency and digital adoption.</p>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="card h-100 p-3 border-0 shadow-sm" style="background: #EFF6FF;">
                                            <div class="fw-bold text-primary mb-1"><i class="fas fa-chart-line me-2" aria-hidden="true"></i>Public Health Digitization</div>
                                            <div class="h6 fw-bold text-dark mb-1">eHealth Africa (2024)</div>
                                            <p class="small text-muted mb-0">Contributed to health data collection, verification, and campaign tracking for child immunisation initiatives. Strengthened his appreciation for data integrity, field coordination, and technology in service delivery.</p>
                                        </div>
                                    </div>
                                </div>

                                <h4 class="h6 fw-bold text-dark mb-2">Educational Mentorship &amp; School Leadership</h4>
                                <p>
                                    Between October 2021 and March 2024, Sani worked as a teacher at Shahrab International School in Katsina State. In this role, he was responsible for classroom instruction, curriculum support, and mentoring secondary school students. The experience reinforced his understanding of education as a foundation for individual development and social awareness.
                                </p>
                                <p>
                                    His background in secondary education contributed to his later interest in environmental literacy. Observing the limited presence of climate and environmental issues in formal school curricula, he recognised the need to introduce young people to sustainability concepts early in their educational development.
                                </p>
                            </div>

                            <!-- Tab 4: GNEP Founding -->
                            <div class="tab-pane fade" id="bio-gnep" role="tabpanel" aria-labelledby="bio-gnep-tab">
                                <span class="badge bg-success bg-opacity-10 text-success fw-bold text-uppercase px-2 py-1 mb-2">Institutional Initiative</span>
                                <h3 class="h4 fw-bold text-dark mb-3">Founding the Global Nature and Environmental Partnership</h3>

                                <p>
                                    In January 2025, Sani founded the <strong>Global Nature and Environmental Partnership (GNEP)</strong>, a youth-led environmental organisation based in Katsina State, Nigeria. The initiative was established to address a persistent gap in African environmental action: the divide between climate policy discussions and community-level realities.
                                </p>

                                <div class="bio-lead-quote">
                                    &ldquo;GNEP was established to ensure that Africa's climate narrative is not just written in conference halls, but enacted through verified local action, youth capacity building, and collaborative institutional partnerships.&rdquo;
                                </div>

                                <div class="row g-3 my-3">
                                    <div class="col-md-4">
                                        <div class="p-3 bg-light rounded text-center">
                                            <div class="h3 fw-bold text-success mb-0">Jan 2025</div>
                                            <span class="small text-muted">Founded in Katsina</span>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="p-3 bg-light rounded text-center">
                                            <div class="h3 fw-bold text-success mb-0">20 CSOs</div>
                                            <span class="small text-muted">Trained in Policy Briefs</span>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="p-3 bg-light rounded text-center">
                                            <div class="h3 fw-bold text-success mb-0">150 Trees</div>
                                            <span class="small text-muted">Planted with AYINET</span>
                                        </div>
                                    </div>
                                </div>

                                <h4 class="h6 fw-bold text-dark mt-3 mb-2">Key GNEP Milestones under Sani's Leadership:</h4>
                                <ul class="list-unstyled small">
                                    <li class="mb-2 d-flex gap-2">
                                        <i class="fas fa-check-circle text-success mt-1" aria-hidden="true"></i>
                                        <div><strong>Policy Brief &amp; Proposal Development Workshop:</strong> Co-hosted with The Green Minds Space for 20 civil society representatives in Katsina State, providing hands-on training on drafting policy briefs, competitive funding proposals, elevator pitches, and responsible AI research tools.</div>
                                    </li>
                                    <li class="mb-2 d-flex gap-2">
                                        <i class="fas fa-check-circle text-success mt-1" aria-hidden="true"></i>
                                        <div><strong>150 Economic Tree Seedling Drive:</strong> Joint community restoration drive with the African Youth Initiative Network (AYINET) across Katsina State, promoting green cover and ecosystem regeneration.</div>
                                    </li>
                                    <li class="mb-2 d-flex gap-2">
                                        <i class="fas fa-check-circle text-success mt-1" aria-hidden="true"></i>
                                        <div><strong>Institutional Climate Education:</strong> Participated in the SUBEB Katsina &amp; UNICEF workshop on Field Work for Climate Change and Green Skills on 19 August 2026.</div>
                                    </li>
                                    <li class="mb-0 d-flex gap-2">
                                        <i class="fas fa-check-circle text-success mt-1" aria-hidden="true"></i>
                                        <div><strong>Grassroots Climate Clubs:</strong> Initiated the rollout of student environmental clubs across secondary schools in Katsina State to foster early climate literacy.</div>
                                    </li>
                                </ul>
                            </div>

                            <!-- Tab 5: Research & Papers -->
                            <div class="tab-pane fade" id="bio-research" role="tabpanel" aria-labelledby="bio-research-tab">
                                <span class="badge bg-success bg-opacity-10 text-success fw-bold text-uppercase px-2 py-1 mb-2">Academic &amp; Policy Portfolio</span>
                                <h3 class="h4 fw-bold text-dark mb-3">Research, Publications, and Policy Contributions</h3>

                                <p>
                                    Research is an increasingly central component of Sani's professional trajectory. His work examines climate finance mechanisms, institutional effectiveness, environmental governance, and the implementation of public policies in African contexts.
                                </p>

                                <!-- Pub 1 -->
                                <div class="publication-card">
                                    <div class="d-flex justify-content-between align-items-start mb-2">
                                        <span class="publication-status-badge pub-review">Policy Paper &bull; Under Review</span>
                                        <span class="small text-muted">2026</span>
                                    </div>
                                    <h4 class="h6 fw-bold text-dark mb-1">How Debt Swaps Can Unlock Finance for Climate Adaptation in Africa</h4>
                                    <p class="small text-muted mb-2">Author: Mohammed Labaran Sani</p>
                                    <p class="small text-dark mb-0">Examines the potential of debt-for-climate and debt-for-adaptation swaps to create fiscal space for vulnerable African nations, relieving sovereign debt distress while funding resilient infrastructure.</p>
                                </div>

                                <!-- Pub 2 -->
                                <div class="publication-card">
                                    <div class="d-flex justify-content-between align-items-start mb-2">
                                        <span class="publication-status-badge pub-review">Working Paper</span>
                                        <span class="small text-muted">In Development</span>
                                    </div>
                                    <h4 class="h6 fw-bold text-dark mb-1">Rethinking Climate Finance in Africa: Governance, Institutional Capacity, and Adaptation Outcomes</h4>
                                    <p class="small text-muted mb-2">Author: Mohammed Labaran Sani</p>
                                    <p class="small text-dark mb-0">Considers the institutional and fiduciary conditions that influence the absorptive capacity and impact of multilateral climate finance on community-level resilience.</p>
                                </div>

                                <!-- Pub 3 -->
                                <div class="publication-card">
                                    <div class="d-flex justify-content-between align-items-start mb-2">
                                        <span class="publication-status-badge pub-review">Comparative Study</span>
                                        <span class="small text-muted">PAUWES Research</span>
                                    </div>
                                    <h4 class="h6 fw-bold text-dark mb-1">Institutional Determinants of Delayed Implementation of National Climate Plans: Comparative Evidence from Nigeria and Cameroon</h4>
                                    <p class="small text-muted mb-2">Author: Mohammed Labaran Sani</p>
                                    <p class="small text-dark mb-0">A comparative institutional analysis exploring why nationally determined contributions (NDCs) encounter bureaucratic delays and policy inertia in Central and West Africa.</p>
                                </div>

                                <!-- Pub 4 -->
                                <div class="publication-card">
                                    <div class="d-flex justify-content-between align-items-start mb-2">
                                        <span class="publication-status-badge pub-review">Spatial-Temporal Analysis</span>
                                        <span class="small text-muted">PAUWES Research</span>
                                    </div>
                                    <h4 class="h6 fw-bold text-dark mb-1">Evaluating Climate Policy Effectiveness in Algeria and Nigeria: A Spatio-Temporal GHG Emissions Analysis (2000&ndash;2025)</h4>
                                    <p class="small text-muted mb-2">Author: Mohammed Labaran Sani</p>
                                    <p class="small text-dark mb-0">Combines satellite data, GIS mapping, and policy timeline benchmarking to evaluate how national mitigation frameworks correlate with emission trajectories in two major oil-producing African states.</p>
                                </div>

                                <!-- Pub 5 -->
                                <div class="publication-card">
                                    <div class="d-flex justify-content-between align-items-start mb-2">
                                        <span class="publication-status-badge pub-training">Fellowship &amp; Training</span>
                                        <span class="small text-muted">April 2026 &bull; Johannesburg</span>
                                    </div>
                                    <h4 class="h6 fw-bold text-dark mb-1">Africa Youth Portal Research Training Programme</h4>
                                    <p class="small text-muted mb-2">South African Institute of International Affairs (SAIIA), South Africa</p>
                                    <p class="small text-dark mb-0">Advanced training in policy evidence synthesis, translating academic research into actionable policy briefs, and engaging high-level African decision-makers.</p>
                                </div>

                                <!-- Pub 6 -->
                                <div class="publication-card">
                                    <div class="d-flex justify-content-between align-items-start mb-2">
                                        <span class="publication-status-badge pub-conference">Conference Presentation</span>
                                        <span class="small text-muted">April 2026</span>
                                    </div>
                                    <h4 class="h6 fw-bold text-dark mb-1">Climate Vulnerability, Education, and Nation-Building: Quantitative Evidence from Katsina State, Nigeria</h4>
                                    <p class="small text-muted mb-2">2nd International Conference of the Faculty of Arts &amp; Social Sciences, Federal University Dutse</p>
                                    <p class="small text-dark mb-0">Co-presented quantitative findings demonstrating how extreme weather impacts school attendance and social cohesion in arid border regions.</p>
                                </div>

                                <!-- Pub 7 -->
                                <div class="publication-card">
                                    <div class="d-flex justify-content-between align-items-start mb-2">
                                        <span class="publication-status-badge pub-published">Monograph / Thesis (Zenodo)</span>
                                        <span class="small text-muted">2021 &bull; Open Access</span>
                                    </div>
                                    <h4 class="h6 fw-bold text-dark mb-1">The African Union (AU), Regional Integration, and the Challenges of Globalisation in the Twenty-First Century</h4>
                                    <p class="small text-muted mb-2">BSc Thesis, Umaru Musa Yar'adua University &bull; Zenodo Archive</p>
                                    <p class="small text-dark mb-0">Investigates the institutional efficacy of the African Union in orchestrating regional economic integration amidst shifting geopolitical dynamics.</p>
                                </div>
                            </div>

                            <!-- Tab 6: Leadership & Vision -->
                            <div class="tab-pane fade" id="bio-vision" role="tabpanel" aria-labelledby="bio-vision-tab">
                                <span class="badge bg-success bg-opacity-10 text-success fw-bold text-uppercase px-2 py-1 mb-2">Strategic Outlook</span>
                                <h3 class="h4 fw-bold text-dark mb-3">Vision for African Climate Governance</h3>

                                <p>
                                    Sani's long-term professional commitment centres on improving the effectiveness of climate governance, public administration, and public policy delivery across Africa.
                                </p>

                                <div class="bio-lead-quote">
                                    &ldquo;For Sani, the future of African climate governance will depend partly on the ability of African researchers, policymakers, civil society organisations, and young leaders to develop solutions informed by evidence and grounded in the continent's institutional and social realities.&rdquo;
                                </div>

                                <h4 class="h6 fw-bold text-dark mt-4 mb-2">Core Strategic Priorities:</h4>
                                <ul class="list-unstyled small">
                                    <li class="mb-3 d-flex gap-3">
                                        <span class="badge bg-success rounded-circle p-2 d-flex align-items-center justify-content-center" style="width: 28px; height: 28px; flex-shrink: 0;"><i class="fas fa-link text-white" aria-hidden="true"></i></span>
                                        <div>
                                            <strong>Climate Policy Practice Platform:</strong> Establishing a Pan-African collaborative hub linking young researchers, civil society actors, and public institutions to co-create actionable policy briefs on adaptation finance and energy transition.
                                        </div>
                                    </li>
                                    <li class="mb-3 d-flex gap-3">
                                        <span class="badge bg-success rounded-circle p-2 d-flex align-items-center justify-content-center" style="width: 28px; height: 28px; flex-shrink: 0;"><i class="fas fa-microscope text-white" aria-hidden="true"></i></span>
                                        <div>
                                            <strong>Evidence-Informed Governance:</strong> Promoting the rigorous use of geospatial data, climate analytics, and AI tools to track environmental spending and ensure funds reach vulnerable communities.
                                        </div>
                                    </li>
                                    <li class="mb-3 d-flex gap-3">
                                        <span class="badge bg-success rounded-circle p-2 d-flex align-items-center justify-content-center" style="width: 28px; height: 28px; flex-shrink: 0;"><i class="fas fa-seedling text-white" aria-hidden="true"></i></span>
                                        <div>
                                            <strong>Community-Driven Nature Solutions:</strong> Scaling youth-led agroforestry, indigenous seed conservation, and climate clubs across schools in the Sahel and Sudan-Guinea savannah belts.
                                        </div>
                                    </li>
                                </ul>

                                <div class="p-3 bg-light rounded-3 mt-4 border-start border-4 border-success">
                                    <div class="fw-bold text-dark small mb-1">Guiding Principle:</div>
                                    <p class="small text-muted mb-0">
                                        &ldquo;The measure of progress lies in whether knowledge informs decisions, whether institutions fulfil their responsibilities, and whether the benefits of public policy reach the people for whom they are intended.&rdquo;
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Modal Footer -->
            <div class="modal-footer bg-light px-4 py-3 border-0 d-flex justify-content-between align-items-center">
                <div class="small text-muted">
                    <i class="fas fa-shield-alt text-success me-1" aria-hidden="true"></i> Strictly verified biographical &amp; academic records
                </div>
                <div class="d-flex gap-2">
                    <a href="founder.html" target="_blank" class="btn btn-outline-success btn-sm">
                        <i class="fas fa-external-link-alt me-1" aria-hidden="true"></i> Open Full Page
                    </a>
                    <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
</div>
"""

# 3. Build Standalone founder.html page
STANDALONE_FOUNDER_HTML = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Mohammed Labaran Sani &bull; Founder &amp; Lead | GNEP Africa</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Mohammed Labaran Sani, GNEP founder, climate policy researcher, PAUWES, Katsina, Nigeria, African climate finance" name="keywords">
    <meta content="Biography, academic publications, and leadership profile of Mohammed Labaran Sani, Founder and Project Lead of Global Nature and Environmental Partnership (GNEP Africa)." name="description">
    
    <!-- Open Graph -->
    <meta property="og:title" content="Mohammed Labaran Sani &bull; Founder &amp; Lead | GNEP Africa">
    <meta property="og:description" content="Biography and research portfolio of Mohammed Labaran Sani &mdash; Climate Policy Researcher and Founder of GNEP Africa.">
    <meta property="og:image" content="assets/real/founder-mohammed-labaran-sani.webp">
    <meta property="og:type" content="profile">

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Newsreader:ital,opsz,wght@0,6..72,400;0,6..72,500;0,6..72,600;1,6..72,400&family=Plus+Jakarta+Sans:wght@500;600;700;800&display=swap" rel="stylesheet"> 

    <!-- Icon Font Stylesheet -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css"/>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/lightbox/css/lightbox.min.css" rel="stylesheet">

    <!-- Customized Bootstrap & Site Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/gnep.css" rel="stylesheet">

    <style>
        .founder-page-hero {{
            position: relative;
            background: linear-gradient(135deg, #0B2516 0%, #153E26 60%, #1A4D2E 100%);
            padding-top: 140px;
            padding-bottom: 70px;
            color: #ffffff;
            overflow: hidden;
        }}
        .founder-page-hero::before {{
            content: '';
            position: absolute;
            inset: 0;
            background: radial-gradient(circle at 80% 30%, rgba(16, 185, 129, 0.18) 0%, transparent 60%);
            pointer-events: none;
        }}
        .founder-content-section {{
            background: #ffffff;
            padding: 4rem 0;
        }}
        .founder-chapter-nav {{
            position: sticky;
            top: 100px;
            background: #FAFCF9;
            border-radius: 12px;
            padding: 1.5rem;
            border: 1px solid #E2E8F0;
        }}
        .founder-chapter-nav a {{
            display: block;
            padding: 0.5rem 0.75rem;
            color: #4A5568;
            text-decoration: none;
            font-size: 0.88rem;
            font-weight: 600;
            border-radius: 6px;
            transition: all 0.2s ease;
        }}
        .founder-chapter-nav a:hover, .founder-chapter-nav a.active {{
            background: #15803D;
            color: #ffffff;
        }}
    </style>
</head>

<body>
    <!-- Skip to main content -->
    <a class="skip-to-content" href="#main-content">Skip to main content</a>

    <!-- Topbar & Navigation -->
    <header class="fixed-top">
        <aside class="gnep-topbar d-none d-md-block" aria-label="Quick Links">
            <div class="container d-flex justify-content-between align-items-center">
                <div class="d-flex align-items-center">
                    <a href="events.html"><i class="fas fa-file-alt me-1" aria-hidden="true"></i> Research and Insights</a>
                    <span class="topbar-divider">|</span>
                    <a href="contact.html"><i class="fas fa-envelope me-1" aria-hidden="true"></i> Contact</a>
                    <span class="topbar-divider">|</span>
                    <a href="https://www.linkedin.com/company/global-nature-environmental-partnership/" target="_blank" rel="noopener noreferrer"><i class="fab fa-linkedin me-1" aria-hidden="true"></i> LinkedIn</a>
                </div>
                <div class="d-flex align-items-center text-white-50 small">
                    <span class="me-3"><i class="fas fa-map-marker-alt text-white me-1" aria-hidden="true"></i> Katsina State, Nigeria</span>
                    <a href="mailto:gnep.partnership@gmail.com" class="text-white"><i class="fas fa-paper-plane me-1" aria-hidden="true"></i> gnep.partnership@gmail.com</a>
                </div>
            </div>
        </aside>

        <nav class="navbar navbar-expand-lg gnep-navbar" aria-label="Main Navigation">
            <div class="container">
                <a href="index.html" class="gnep-brand-wrap" aria-label="GNEP Africa Homepage">
                    <img src="assets/real/gnep-logo.webp" alt="GNEP Logo" class="gnep-brand-logo" width="160" height="48">
                    <div class="gnep-brand-text d-none d-sm-block">
                        <span class="gnep-brand-title">GNEP Africa</span>
                        <span class="gnep-brand-sub">Global Nature &amp; Environmental Partnership</span>
                    </div>
                </a>
                <button class="navbar-toggler py-2 px-3" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation menu">
                    <span class="fa fa-bars text-dark fs-5"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarCollapse">
                    <ul class="navbar-nav ms-auto align-items-lg-center">
                        <li class="nav-item"><a href="about.html" class="nav-link active">About GNEP</a></li>
                        <li class="nav-item dropdown">
                            <a href="index.html#focus-areas" class="nav-link dropdown-toggle" id="workDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">Our Work</a>
                            <ul class="dropdown-menu" aria-labelledby="workDropdown">
                                <li><a class="dropdown-item" href="index.html#focus-areas">1. Climate Action &amp; Resilience</a></li>
                                <li><a class="dropdown-item" href="index.html#focus-areas">2. Nature &amp; Ecosystem Restoration</a></li>
                                <li><a class="dropdown-item" href="index.html#focus-areas">3. Environmental Governance &amp; Policy</a></li>
                                <li><a class="dropdown-item" href="index.html#focus-areas">4. Youth Leadership &amp; Participation</a></li>
                                <li><a class="dropdown-item" href="index.html#focus-areas">5. WEFE Nexus <span class="badge bg-secondary ms-1 text-dark">Strategic Direction</span></a></li>
                                <li><a class="dropdown-item" href="index.html#focus-areas">6. Research &amp; Capacity Development</a></li>
                            </ul>
                        </li>
                        <li class="nav-item dropdown">
                            <a href="events.html" class="nav-link dropdown-toggle" id="updatesDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">Updates</a>
                            <ul class="dropdown-menu" aria-labelledby="updatesDropdown">
                                <li><a class="dropdown-item" href="events.html">Events &amp; Workshops</a></li>
                                <li><a class="dropdown-item" href="events.html">Research &amp; Insights</a></li>
                                <li><a class="dropdown-item" href="gallery.html">Field Gallery</a></li>
                            </ul>
                        </li>
                        <li class="nav-item"><a href="contact.html" class="nav-link">Get Involved</a></li>
                    </ul>
                    <div class="d-flex align-items-center ms-lg-3 mt-3 mt-lg-0">
                        <a href="contact.html" class="btn-partner-nav text-center w-100 w-lg-auto">Partner With Us</a>
                    </div>
                </div>
            </div>
        </nav>
    </header>

    <main id="main-content">
        <!-- Hero Header -->
        <section class="founder-page-hero" aria-label="Founder Header">
            <div class="container">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb" style="background: none; padding: 0; margin-bottom: 1.5rem;">
                        <li class="breadcrumb-item"><a href="index.html" class="text-white-50 text-decoration-none">Home</a></li>
                        <li class="breadcrumb-item"><a href="about.html" class="text-white-50 text-decoration-none">About</a></li>
                        <li class="breadcrumb-item active text-white" aria-current="page">Founder Profile</li>
                    </ol>
                </nav>
                <div class="row align-items-center g-4">
                    <div class="col-lg-3 col-md-4 text-center text-md-start">
                        <div class="gnep-founder-portrait-frame" style="max-width: 260px; margin: 0 auto;">
                            <img src="assets/real/founder-mohammed-labaran-sani.webp" alt="Mohammed Labaran Sani portrait" class="gnep-founder-portrait-img">
                        </div>
                    </div>
                    <div class="col-lg-9 col-md-8">
                        <span class="badge bg-success bg-opacity-25 text-white border border-success border-opacity-50 px-3 py-1 rounded-pill mb-2">Founder &amp; Project Lead</span>
                        <h1 class="display-5 fw-bold text-white mb-2">Mohammed Labaran Sani</h1>
                        <p class="lead text-white-50 mb-3" style="font-size: 1.25rem;">Climate Policy Researcher &bull; Pan-African Development Practitioner &bull; Social Entrepreneur</p>
                        
                        <div class="d-flex flex-wrap gap-2 mb-4">
                            <span class="badge bg-light text-dark px-3 py-2"><i class="fas fa-university text-success me-1"></i> PAUWES MSc Scholar (Algeria)</span>
                            <span class="badge bg-light text-dark px-3 py-2"><i class="fas fa-map-marker-alt text-success me-1"></i> Katsina State, Nigeria</span>
                            <span class="badge bg-light text-dark px-3 py-2"><i class="fas fa-book-reader text-success me-1"></i> SAIIA Research Fellow 2026</span>
                        </div>

                        <div class="d-flex flex-wrap gap-3">
                            <a href="mailto:gnep.partnership@gmail.com?subject=Partnership%20Inquiry%20for%20Mohammed%20Labaran%20Sani" class="btn btn-success px-4 py-2">
                                <i class="fas fa-envelope me-2" aria-hidden="true"></i>Contact Directly
                            </a>
                            <a href="https://www.linkedin.com/company/global-nature-environmental-partnership/" target="_blank" rel="noopener noreferrer" class="btn btn-outline-light px-4 py-2">
                                <i class="fab fa-linkedin me-2" aria-hidden="true"></i>LinkedIn Profile
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Main Body -->
        <section class="founder-content-section" aria-label="Founder Biography and Research">
            <div class="container">
                <div class="row g-5">
                    <!-- Left Sticky TOC Sidebar -->
                    <div class="col-lg-4">
                        <div class="founder-chapter-nav mb-4">
                            <div class="fw-bold text-dark small text-uppercase mb-3" style="letter-spacing: 0.08em;">Chapters</div>
                            <a href="#overview" class="active"><i class="fas fa-chevron-right me-2 text-success small"></i>1. Overview &amp; Biography</a>
                            <a href="#academic"><i class="fas fa-chevron-right me-2 text-success small"></i>2. Academic Foundations</a>
                            <a href="#experience"><i class="fas fa-chevron-right me-2 text-success small"></i>3. Professional Experience</a>
                            <a href="#gnep"><i class="fas fa-chevron-right me-2 text-success small"></i>4. Founding GNEP Africa</a>
                            <a href="#research"><i class="fas fa-chevron-right me-2 text-success small"></i>5. Research &amp; Publications</a>
                            <a href="#leadership"><i class="fas fa-chevron-right me-2 text-success small"></i>6. Leadership &amp; Service</a>
                            <a href="#vision"><i class="fas fa-chevron-right me-2 text-success small"></i>7. Vision for African Governance</a>
                        </div>

                        <!-- Credentials Box -->
                        <div class="founder-meta-box">
                            <div class="founder-meta-title">Key Credentials</div>
                            <div class="founder-meta-item">
                                <i class="fas fa-check-circle" aria-hidden="true"></i>
                                <div><strong>MSc Climate Change Policy</strong><br><span class="small text-muted">PAUWES, Algeria (2027)</span></div>
                            </div>
                            <div class="founder-meta-item">
                                <i class="fas fa-check-circle" aria-hidden="true"></i>
                                <div><strong>BSc Political Science</strong><br><span class="small text-muted">UMYU Katsina (2021)</span></div>
                            </div>
                            <div class="founder-meta-item">
                                <i class="fas fa-check-circle" aria-hidden="true"></i>
                                <div><strong>12,000+ Youth &amp; Women Trained</strong><br><span class="small text-muted">Jobberman Nigeria (2023&ndash;2024)</span></div>
                            </div>
                            <div class="founder-meta-item">
                                <i class="fas fa-check-circle" aria-hidden="true"></i>
                                <div><strong>SAIIA Research Fellow</strong><br><span class="small text-muted">Johannesburg, South Africa (2026)</span></div>
                            </div>
                        </div>
                    </div>

                    <!-- Right Editorial Content -->
                    <div class="col-lg-8">
                        <!-- Chapter 1: Overview -->
                        <div id="overview" class="mb-5 pt-2">
                            <span class="gnep-section-tag">Chapter 1</span>
                            <h2 class="h3 fw-bold text-dark mb-3">Executive Overview &amp; Background</h2>
                            <p class="lead text-dark" style="font-size: 1.1rem; line-height: 1.75;">
                                Mohammed Labaran Sani is a Nigerian climate policy researcher, development practitioner, and social entrepreneur whose work focuses on climate governance, adaptation finance, institutional effectiveness, and community-led environmental action in Africa.
                            </p>
                            <p>
                                With an academic foundation in Political Science and postgraduate training in Climate Change Policy, he works at the intersection of research, public policy, and practical development. His professional journey spans education, public health programme support, entrepreneurship training, environmental advocacy, and youth leadership, reflecting a sustained interest in how institutions can translate policy commitments into meaningful outcomes for communities.
                            </p>
                            <div class="bio-lead-quote">
                                &ldquo;Ambitious climate commitments mean little if they fail to produce corresponding improvements in the lives of the communities they are intended to protect. Our responsibility is to turn policy ambition into institutional delivery.&rdquo;
                            </div>
                            <p>
                                He is the Founder and Project Lead of the <strong>Global Nature and Environmental Partnership (GNEP)</strong>, a youth-led environmental initiative established to advance climate literacy, renewable energy awareness, sustainable livelihoods, and evidence-informed environmental governance. Through GNEP, he seeks to strengthen the participation of young people and civil society organisations in climate policy processes, particularly in underserved communities in Nigeria. His research examines the institutional and financial barriers that limit climate action across Africa, with particular attention to the implementation of national climate policies and the delivery of adaptation finance.
                            </p>
                            <p>
                                Currently pursuing a Master of Science in Climate Change Policy at the <strong>Pan-African University Institute for Water and Energy Sciences, including Climate Change (PAUWES)</strong>, in Algeria, Sani is developing an interdisciplinary approach to African development challenges. His work connects political institutions, public policy, environmental sustainability, and the economic conditions that shape communities' capacity to respond to climate change.
                            </p>
                        </div>

                        <!-- Chapter 2: Academic Foundations -->
                        <div id="academic" class="mb-5 pt-2 border-top pt-4">
                            <span class="gnep-section-tag">Chapter 2</span>
                            <h2 class="h3 fw-bold text-dark mb-3">Academic Foundations and Intellectual Development</h2>
                            <p>
                                Sani's academic development began with an interest in political institutions, public administration, regional integration, and the processes through which governments make and implement decisions. He obtained a Diploma in Office Technology and Management Studies from Hassan Usman Katsina Polytechnic in Nigeria in 2015. The programme provided an early foundation in administration, organisation, communication, and information management, skills that would later support his work in programme coordination and institutional engagement.
                            </p>
                            <p>
                                He subsequently studied Political Science at Umaru Musa Yar'adua University in Katsina State, graduating in 2021 with a Bachelor of Science degree. His undergraduate studies examined the structures of political authority, public policy, international relations, political economy, development administration, and the relationship between institutions and society. These areas of study helped establish the analytical foundation for his subsequent interests in governance and development policy.
                            </p>
                            <h3 class="h5 fw-bold text-dark mt-4 mb-2">The African Union &amp; Regional Integration Thesis</h3>
                            <p>
                                His undergraduate research focused on <em>The African Union (AU), Regional Integration, and the Challenges of Globalisation in the Twenty-First Century</em>. The study examined regional integration as a pathway for African cooperation and development while considering the challenges that shape the continent's position in an increasingly interconnected global system. The thesis, subsequently made available through Zenodo, reflects his early engagement with questions concerning African institutions, regional cooperation, and the implementation of collective development ambitions.
                            </p>
                            <p>
                                This initial research direction remains relevant to his present work. His transition from political science to climate policy reflects a continuing interest in the relationship between institutional commitments and practical outcomes. While his undergraduate research examined the African Union and regional integration, his current work considers how African governments and institutions can improve the delivery of climate policies, mobilise resources, and respond to the needs of vulnerable populations.
                            </p>
                            <p>
                                Sani is currently pursuing an MSc in Climate Change Policy at PAUWES in Tlemcen, Algeria, with completion expected in August 2027. His postgraduate studies extend his earlier interest in public policy into environmental governance, climate adaptation, mitigation planning, climate finance, and sustainable energy transitions. Through this training, he is developing the capacity to examine climate change as both an environmental challenge and a governance issue shaped by institutional performance, financing arrangements, and policy choices.
                            </p>
                        </div>

                        <!-- Chapter 3: Professional Experience -->
                        <div id="experience" class="mb-5 pt-2 border-top pt-4">
                            <span class="gnep-section-tag">Chapter 3</span>
                            <h2 class="h3 fw-bold text-dark mb-3">Professional Experience and Community Engagement</h2>
                            <p>
                                Sani's professional experience spans education, public health, entrepreneurship development, and environmental action. These roles provided practical exposure to community realities, organisational coordination, and the challenges of programme delivery.
                            </p>
                            <p>
                                Between October 2021 and March 2024, he worked as a teacher at Shahrab International School in Katsina State. In this role, he was responsible for classroom instruction, curriculum support, and mentoring secondary school students. The experience reinforced his understanding of education as a foundation for individual development and social awareness. Observing the limited presence of climate and environmental issues in formal school curricula, he recognised the need to introduce young people to sustainability concepts early in their educational development.
                            </p>
                            <div class="row g-3 my-4">
                                <div class="col-md-6">
                                    <div class="p-3 bg-light rounded-3 border-start border-4 border-success">
                                        <div class="fw-bold text-dark mb-1">Jobberman Nigeria (2023&ndash;2024)</div>
                                        <p class="small text-muted mb-0">Delivered soft-skills and entrepreneurship training reaching over 12,000 market women and young people across Kano, Kaduna, and Katsina states under the Mastercard Foundation Young Africa Works programme.</p>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="p-3 bg-light rounded-3 border-start border-4 border-primary">
                                        <div class="fw-bold text-dark mb-1">eHealth Africa (2024)</div>
                                        <p class="small text-muted mb-0">Provided digital data collection and technological field support for public health campaigns and childhood immunisation monitoring, ensuring rigorous data integrity.</p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Chapter 4: Founding GNEP -->
                        <div id="gnep" class="mb-5 pt-2 border-top pt-4">
                            <span class="gnep-section-tag">Chapter 4</span>
                            <h2 class="h3 fw-bold text-dark mb-3">Founding the Global Nature and Environmental Partnership</h2>
                            <p>
                                In January 2025, Sani founded the <strong>Global Nature and Environmental Partnership (GNEP)</strong>, a youth-led environmental organisation based in Katsina State, Nigeria. The initiative was established to address a persistent gap in African environmental action: the divide between climate policy discussions and community-level realities.
                            </p>
                            <p>
                                While international forums and national policy documents frequently articulate ambitious climate goals, local communities often have limited access to the information, resources, and institutional support needed to adapt to changing environmental conditions. GNEP was designed to help bridge this gap by translating environmental policy and scientific knowledge into accessible educational programmes and community-level initiatives.
                            </p>
                            <div class="p-4 bg-light rounded-3 my-4">
                                <h4 class="h6 fw-bold text-dark mb-2">Ground-Truthed Achievements under GNEP:</h4>
                                <ul class="list-unstyled small mb-0">
                                    <li class="mb-2"><i class="fas fa-check text-success me-2"></i><strong>20 Civil Society Representatives Trained:</strong> Workshop on policy brief writing, proposal development, elevator pitching, and ethical AI research tools in Katsina State.</li>
                                    <li class="mb-2"><i class="fas fa-check text-success me-2"></i><strong>150 Economic Tree Seedlings Planted:</strong> Joint initiative with AYINET to promote reforestation and agroforestry in northern Nigeria.</li>
                                    <li class="mb-2"><i class="fas fa-check text-success me-2"></i><strong>SUBEB &amp; UNICEF Workshop:</strong> Active participation in institutional field work approaches for climate change and green skills (19 August 2026).</li>
                                    <li class="mb-0"><i class="fas fa-check text-success me-2"></i><strong>Climate Clubs in Schools:</strong> Establishing student-led environmental awareness networks across Katsina State schools.</li>
                                </ul>
                            </div>
                        </div>

                        <!-- Chapter 5: Research & Papers -->
                        <div id="research" class="mb-5 pt-2 border-top pt-4">
                            <span class="gnep-section-tag">Chapter 5</span>
                            <h2 class="h3 fw-bold text-dark mb-3">Research, Publications, and Policy Contributions</h2>
                            <p>
                                Research is an increasingly important component of Sani's professional trajectory. His work examines climate finance, institutional effectiveness, environmental governance, and the implementation of public policies in African contexts.
                            </p>

                            <div class="publication-card">
                                <div class="d-flex justify-content-between align-items-start mb-2">
                                    <span class="publication-status-badge pub-review">Policy Paper &bull; Under Review</span>
                                    <span class="small text-muted">2026</span>
                                </div>
                                <h4 class="h5 fw-bold text-dark mb-1">How Debt Swaps Can Unlock Finance for Climate Adaptation in Africa</h4>
                                <p class="small text-muted mb-2">Author: Mohammed Labaran Sani</p>
                                <p class="small text-dark mb-0">Examines the potential of debt-for-climate and debt-for-adaptation swaps to create fiscal space for vulnerable African nations, relieving sovereign debt distress while funding resilient infrastructure.</p>
                            </div>

                            <div class="publication-card">
                                <div class="d-flex justify-content-between align-items-start mb-2">
                                    <span class="publication-status-badge pub-review">Working Paper</span>
                                    <span class="small text-muted">In Development</span>
                                </div>
                                <h4 class="h5 fw-bold text-dark mb-1">Rethinking Climate Finance in Africa: Governance, Institutional Capacity, and Adaptation Outcomes</h4>
                                <p class="small text-muted mb-2">Author: Mohammed Labaran Sani</p>
                                <p class="small text-dark mb-0">Considers the institutional and fiduciary conditions that influence the absorptive capacity and impact of multilateral climate finance on community-level resilience.</p>
                            </div>

                            <div class="publication-card">
                                <div class="d-flex justify-content-between align-items-start mb-2">
                                    <span class="publication-status-badge pub-review">Comparative Study</span>
                                    <span class="small text-muted">PAUWES Research</span>
                                </div>
                                <h4 class="h5 fw-bold text-dark mb-1">Institutional Determinants of Delayed Implementation of National Climate Plans: Comparative Evidence from Nigeria and Cameroon</h4>
                                <p class="small text-muted mb-2">Author: Mohammed Labaran Sani</p>
                                <p class="small text-dark mb-0">A comparative institutional analysis exploring why nationally determined contributions (NDCs) encounter bureaucratic delays and policy inertia in Central and West Africa.</p>
                            </div>

                            <div class="publication-card">
                                <div class="d-flex justify-content-between align-items-start mb-2">
                                    <span class="publication-status-badge pub-review">Spatial-Temporal Analysis</span>
                                    <span class="small text-muted">PAUWES Research</span>
                                </div>
                                <h4 class="h5 fw-bold text-dark mb-1">Evaluating Climate Policy Effectiveness in Algeria and Nigeria: A Spatio-Temporal GHG Emissions Analysis (2000&ndash;2025)</h4>
                                <p class="small text-muted mb-2">Author: Mohammed Labaran Sani</p>
                                <p class="small text-dark mb-0">Combines satellite data, GIS mapping, and policy timeline benchmarking to evaluate how national mitigation frameworks correlate with emission trajectories in two major oil-producing African states.</p>
                            </div>

                            <div class="publication-card">
                                <div class="d-flex justify-content-between align-items-start mb-2">
                                    <span class="publication-status-badge pub-training">Fellowship &amp; Training</span>
                                    <span class="small text-muted">April 2026 &bull; Johannesburg</span>
                                </div>
                                <h4 class="h5 fw-bold text-dark mb-1">Africa Youth Portal Research Training Programme</h4>
                                <p class="small text-muted mb-2">South African Institute of International Affairs (SAIIA), South Africa</p>
                                <p class="small text-dark mb-0">Advanced training in policy evidence synthesis, translating academic research into actionable policy briefs, and engaging high-level African decision-makers.</p>
                            </div>

                            <div class="publication-card">
                                <div class="d-flex justify-content-between align-items-start mb-2">
                                    <span class="publication-status-badge pub-conference">Conference Presentation</span>
                                    <span class="small text-muted">April 2026</span>
                                </div>
                                <h4 class="h5 fw-bold text-dark mb-1">Climate Vulnerability, Education, and Nation-Building: Quantitative Evidence from Katsina State, Nigeria</h4>
                                <p class="small text-muted mb-2">2nd International Conference of the Faculty of Arts &amp; Social Sciences, Federal University Dutse</p>
                                <p class="small text-dark mb-0">Co-presented quantitative findings demonstrating how extreme weather impacts school attendance and social cohesion in arid border regions.</p>
                            </div>

                            <div class="publication-card">
                                <div class="d-flex justify-content-between align-items-start mb-2">
                                    <span class="publication-status-badge pub-published">Monograph / Thesis (Zenodo)</span>
                                    <span class="small text-muted">2021 &bull; Open Access</span>
                                </div>
                                <h4 class="h5 fw-bold text-dark mb-1">The African Union (AU), Regional Integration, and the Challenges of Globalisation in the Twenty-First Century</h4>
                                <p class="small text-muted mb-2">BSc Thesis, Umaru Musa Yar'adua University &bull; Zenodo Archive</p>
                                <p class="small text-dark mb-0">Investigates the institutional efficacy of the African Union in orchestrating regional economic integration amidst shifting geopolitical dynamics.</p>
                            </div>
                        </div>

                        <!-- Chapter 6: Leadership & Service -->
                        <div id="leadership" class="mb-5 pt-2 border-top pt-4">
                            <span class="gnep-section-tag">Chapter 6</span>
                            <h2 class="h3 fw-bold text-dark mb-3">Leadership, Service, and Professional Development</h2>
                            <p>
                                Sani's commitment to leadership and service predates his current environmental work. During his undergraduate studies, he participated actively in student governance and youth organisations. He served as Secretary-General of the National Union of Katsina State Students (NUKSS) in 2021, and held the position of Director of Socials within the Department of Political Science at Umaru Musa Yar'adua University in 2019.
                            </p>
                            <p>
                                During his National Youth Service Corps (NYSC) experience, he served as Secretary-General of the Agro-Allied Community Development Service (CDS) group in Katsina State. The role involved coordinating community-based agricultural and environmental initiatives, organising meetings, maintaining records, and facilitating collaboration among corps members and local stakeholders.
                            </p>
                            <p>
                                In 2021, Sani was honoured as an <strong>Outstanding Student Leader</strong> in the Department of Political Science at Umaru Musa Yar'adua University, acknowledging his exceptional dedication to student welfare and academic advocacy.
                            </p>
                        </div>

                        <!-- Chapter 7: Vision for Africa -->
                        <div id="vision" class="mb-5 pt-2 border-top pt-4">
                            <span class="gnep-section-tag">Chapter 7</span>
                            <h2 class="h3 fw-bold text-dark mb-3">Vision for African Climate Governance</h2>
                            <p>
                                Sani's long-term professional interests centre on improving the effectiveness of climate governance and public policy in Africa. He is particularly concerned with the institutional and financial conditions that determine whether climate commitments translate into practical adaptation, resilience, and sustainable development.
                            </p>
                            <div class="bio-lead-quote">
                                &ldquo;For Sani, the future of African climate governance will depend partly on the ability of African researchers, policymakers, civil society organisations, and young leaders to develop solutions informed by evidence and grounded in the continent's institutional and social realities.&rdquo;
                            </div>
                            <p>
                                His immediate research direction includes examining policy implementation and climate governance in West Africa. He aims to deepen his understanding of how public institutions coordinate climate action, how financing reaches intended beneficiaries, and how evidence can be used to improve programme design and accountability.
                            </p>
                            <p>
                                Through GNEP, he intends to continue developing opportunities for young researchers and civil society practitioners to participate in policy processes. One of his proposed initiatives is a climate policy practice platform that would bring researchers and civil society organisations together to address practical policy problems, develop evidence-based recommendations, and strengthen the capacity of local actors to engage with decision-makers.
                            </p>
                            <p class="text-muted small">
                                For Mohammed Labaran Sani, the measure of progress lies in whether knowledge informs decisions, whether institutions fulfil their responsibilities, and whether the benefits of public policy reach the people for whom they are intended.
                            </p>

                            <div class="mt-4 pt-3 border-top d-flex gap-3">
                                <a href="contact.html" class="btn btn-success"><i class="fas fa-handshake me-2"></i>Collaborate with Sani</a>
                                <a href="index.html" class="btn btn-outline-dark"><i class="fas fa-arrow-left me-2"></i>Back to Homepage</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>

    <!-- Standard GNEP Footer -->
    <footer class="gnep-footer" id="contact" aria-label="Footer and Contact Information">
        <div class="container">
            <div class="row g-4">
                <div class="col-lg-4 col-md-6">
                    <div class="d-flex align-items-center mb-3">
                        <img src="assets/real/gnep-logo.webp" alt="GNEP Logo" class="bg-white p-1 rounded" width="130" height="40" style="object-fit: contain;">
                    </div>
                    <p class="small text-light-50 mb-3" style="color: #BFD3C7;">
                        Global Nature and Environmental Partnership (GNEP Africa) is a youth-led initiative connecting climate research, policy, and education with practical community action across Africa.
                    </p>
                    <div class="small" style="color: #9EBAAB;">
                        <div><strong>Founded:</strong> 2025</div>
                        <div><strong>Base:</strong> Katsina State, Nigeria &bull; <strong>Outlook:</strong> Africa</div>
                    </div>
                    <div class="gnep-footer-approach mt-3">
                        <strong>Our Approach:</strong> We are committed to evidence-informed action, strictly verified data reporting, and transparently crediting all community and institutional partners.
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <h4>Our Work</h4>
                    <ul class="footer-link-list">
                        <li><a href="index.html#focus-areas"><i class="fas fa-angle-right me-2 text-success" aria-hidden="true"></i>Climate Action &amp; Resilience</a></li>
                        <li><a href="index.html#focus-areas"><i class="fas fa-angle-right me-2 text-success" aria-hidden="true"></i>Nature &amp; Ecosystem Restoration</a></li>
                        <li><a href="index.html#focus-areas"><i class="fas fa-angle-right me-2 text-success" aria-hidden="true"></i>Environmental Governance &amp; Policy</a></li>
                        <li><a href="index.html#focus-areas"><i class="fas fa-angle-right me-2 text-success" aria-hidden="true"></i>Youth Leadership &amp; Participation</a></li>
                        <li><a href="index.html#focus-areas"><i class="fas fa-angle-right me-2 text-success" aria-hidden="true"></i>WEFE Nexus (Strategic Direction)</a></li>
                        <li><a href="index.html#focus-areas"><i class="fas fa-angle-right me-2 text-success" aria-hidden="true"></i>Research &amp; Capacity Development</a></li>
                    </ul>
                </div>
                <div class="col-lg-2 col-md-6">
                    <h4>Get Involved</h4>
                    <ul class="footer-link-list">
                        <li><a href="contact.html"><i class="fas fa-angle-right me-2 text-success" aria-hidden="true"></i>Partner With Us</a></li>
                        <li><a href="contact.html"><i class="fas fa-angle-right me-2 text-success" aria-hidden="true"></i>Join Our Team</a></li>
                        <li><a href="gallery.html"><i class="fas fa-angle-right me-2 text-success" aria-hidden="true"></i>Field Gallery</a></li>
                        <li><a href="about.html"><i class="fas fa-angle-right me-2 text-success" aria-hidden="true"></i>Our Mission &amp; Values</a></li>
                    </ul>
                </div>
                <div class="col-lg-3 col-md-6">
                    <h4>Contact Us</h4>
                    <div class="mb-3 small" style="color: #BFD3C7;">
                        <p class="mb-2"><i class="fas fa-envelope text-success me-2" aria-hidden="true"></i><a href="mailto:gnep.partnership@gmail.com">gnep.partnership@gmail.com</a></p>
                        <p class="mb-2"><i class="fas fa-phone-alt text-success me-2" aria-hidden="true"></i><a href="tel:+2347065885070">+234 706 588 5070</a></p>
                        <p class="mb-0"><i class="fas fa-map-marker-alt text-success me-2" aria-hidden="true"></i>Katsina State, Nigeria</p>
                    </div>
                    <div class="mt-4 pt-2 border-top border-secondary">
                        <span class="small d-block text-muted mb-2">Connect With GNEP Africa:</span>
                        <a href="https://www.linkedin.com/company/global-nature-environmental-partnership/" target="_blank" rel="noopener noreferrer" class="btn btn-sm btn-outline-light me-2" aria-label="LinkedIn - GNEP Africa"><i class="fab fa-linkedin me-1" aria-hidden="true"></i> LinkedIn</a>
                        <a href="mailto:gnep.partnership@gmail.com" class="btn btn-sm btn-outline-light" aria-label="Email GNEP"><i class="fas fa-envelope me-1" aria-hidden="true"></i> Email</a>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <!-- Bottom Legal Bar -->
    <div class="gnep-legal-bar" aria-label="Legal and Copyright">
        <div class="container">
            <div class="row align-items-center gy-2">
                <div class="col-md-6 text-center text-md-start">
                    &copy; 2026 Global Nature and Environmental Partnership (GNEP Africa). All rights reserved.
                </div>
                <div class="col-md-6 text-center text-md-end">
                    <span class="me-3 text-white-50">Photography &copy; GNEP &amp; AYINET</span>
                    <a href="#" class="text-decoration-none text-muted me-2">Privacy</a>&bull;
                    <a href="#" class="text-decoration-none text-muted mx-2">Terms</a>&bull;
                    <a href="#" class="text-decoration-none text-muted ms-2">Accessibility</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
"""

# Write founder.html
founder_path = os.path.join(BASE_DIR, "founder.html")
with open(founder_path, "w", encoding="utf-8") as f:
    f.write(STANDALONE_FOUNDER_HTML)
print(f"Created {founder_path}")

# 4. Update index.html
index_path = os.path.join(BASE_DIR, "index.html")
with open(index_path, "r", encoding="utf-8") as f:
    index_content = f.read()

# Replace founder card in index.html
old_founder_card_pattern = r'<!-- Founder Profile -->\s*<div class="col-lg-7">.*?</div>\s*</div>\s*</div>\s*</div>'
# Let's inspect the exact lines in index.html around line 512
new_index_founder_card = """<!-- Founder Profile (Interactive Bio Trigger) -->
                    <div class="col-lg-7">
                        <div class="founder-card founder-card-interactive" data-bs-toggle="modal" data-bs-target="#founderBioModal" title="Click to read full biography & research publications" role="button" tabindex="0" aria-haspopup="dialog">
                            <span class="founder-card-cta-badge"><i class="fas fa-book-open" aria-hidden="true"></i> Read Bio</span>
                            <div class="row align-items-center g-4">
                                <div class="col-md-5">
                                    <div class="gnep-founder-portrait-frame">
                                        <img src="assets/real/founder-mohammed-labaran-sani.webp" alt="Mohammed Labaran Sani portrait" class="img-fluid rounded border" width="400" height="400" style="object-fit: cover; width: 100%; aspect-ratio: 1/1;">
                                    </div>
                                    <span class="small text-muted d-block mt-2 text-center" style="font-size: 0.75rem;"><i class="fas fa-hand-pointer text-success me-1"></i> Click to read full biography</span>
                                </div>
                                <div class="col-md-7">
                                    <span class="founder-title-badge">Founder &amp; Lead (Since Jan 2025)</span>
                                    <h3 class="founder-name">Mohammed Labaran Sani</h3>
                                    <div class="founder-role">MSc Climate Change Policy Candidate, PAUWES (Algeria)</div>
                                    <p class="founder-bio">
                                        Mohammed brings a background in political science and public policy to environmental action. As an MSc candidate at PAUWES in Tlemcen, Algeria, his research and advocacy focus on bridging climate science with community-level realities.
                                    </p>
                                    <p class="founder-bio mb-2">
                                        <strong>Core Focus Areas:</strong> Climate governance, debt-for-adaptation swaps, climate finance mechanisms, and sustainable energy transitions.
                                    </p>
                                    <div class="founder-focus-tags mb-3">
                                        <span class="founder-tag">Climate Governance</span>
                                        <span class="founder-tag">Climate Finance</span>
                                        <span class="founder-tag">Environmental Policy</span>
                                        <span class="founder-tag">PAUWES Scholar</span>
                                    </div>
                                    <div class="d-flex align-items-center gap-2">
                                        <button type="button" class="btn btn-sm btn-success rounded-pill px-3 py-1" data-bs-toggle="modal" data-bs-target="#founderBioModal">
                                            <i class="fas fa-book-reader me-1" aria-hidden="true"></i> Full Biography &amp; Research
                                        </button>
                                        <a href="founder.html" target="_blank" class="btn btn-sm btn-outline-secondary rounded-pill px-2 py-1" title="Open full profile in new tab" onclick="event.stopPropagation();">
                                            <i class="fas fa-external-link-alt" aria-hidden="true"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>"""

# Let's replace the founder card block in index.html
# Find the start: <!-- Founder Profile -->
start_idx = index_content.find("<!-- Founder Profile -->")
if start_idx != -1:
    end_marker = "<!-- Associated Leads & Open Team Call -->"
    end_idx = index_content.find(end_marker, start_idx)
    if end_idx != -1:
        index_content = index_content[:start_idx] + new_index_founder_card + "\n\n                    " + index_content[end_idx:]
        print("Updated founder card in index.html")
    else:
        print("Could not find end marker in index.html")
else:
    print("Could not find <!-- Founder Profile --> in index.html")

# Insert modal before </main> if not present
if "id=\"founderBioModal\"" not in index_content:
    main_end_idx = index_content.find("</main>")
    if main_end_idx != -1:
        index_content = index_content[:main_end_idx] + "\n" + MODAL_HTML + "\n    " + index_content[main_end_idx:]
        print("Inserted founderBioModal into index.html")
    else:
        print("Could not find </main> in index.html")
else:
    print("founderBioModal already present in index.html")

with open(index_path, "w", encoding="utf-8") as f:
    f.write(index_content)


# 5. Update about.html
about_path = os.path.join(BASE_DIR, "about.html")
with open(about_path, "r", encoding="utf-8") as f:
    about_content = f.read()

new_about_founder_card = """<!-- Founder Card (Interactive Bio Trigger) -->
                    <div class="col-lg-5">
                        <div class="gnep-team-card founder-card-interactive spatial-tilt-card-featured" data-bs-toggle="modal" data-bs-target="#founderBioModal" role="button" tabindex="0" title="Click to read full biography & research publications">
                            <span class="founder-card-cta-badge"><i class="fas fa-book-open" aria-hidden="true"></i> Read Bio</span>
                            <div class="gnep-founder-portrait-frame mb-3">
                                <img src="assets/real/founder-mohammed-labaran-sani.webp" alt="Mohammed Labaran Sani, Founder and Lead of GNEP Africa" class="img-fluid rounded-3" loading="lazy" style="width: 100%; aspect-ratio: 1/1; object-fit: cover;">
                            </div>
                            <div class="gnep-team-card-featured-body mt-2">
                                <span class="gnep-focus-tag mb-2 d-inline-block" style="background: #0B2516; color: #fff;">Founder &amp; Lead</span>
                                <h3 class="h4 fw-bold text-dark mb-1">Mohammed Labaran Sani</h3>
                                <p class="small text-muted mb-2">Since January 2025 &bull; Katsina State, Nigeria</p>
                                <p class="text-muted small">Background in political science and public policy. MSc Climate Change Policy candidate at PAUWES (Pan African University Institute for Water and Energy Sciences), Tlemcen, Algeria.</p>
                                <p class="text-muted small mb-3">Research interests: climate governance, debt-for-adaptation swaps, climate finance, and energy transition.</p>
                                <div class="d-flex align-items-center gap-2">
                                    <button type="button" class="btn btn-sm btn-success rounded-pill px-3 py-1" data-bs-toggle="modal" data-bs-target="#founderBioModal">
                                        <i class="fas fa-book-reader me-1" aria-hidden="true"></i> View Full Biography
                                    </button>
                                    <a href="founder.html" target="_blank" class="btn btn-sm btn-outline-secondary rounded-pill px-2 py-1" title="Open full profile in new tab" onclick="event.stopPropagation();">
                                        <i class="fas fa-external-link-alt" aria-hidden="true"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>"""

start_about_idx = about_content.find("<!-- Founder Card -->")
if start_about_idx != -1:
    end_about_marker = "<!-- Project Leads -->"
    end_about_idx = about_content.find(end_about_marker, start_about_idx)
    if end_about_idx != -1:
        about_content = about_content[:start_about_idx] + new_about_founder_card + "\n                    " + about_content[end_about_idx:]
        print("Updated founder card in about.html")
    else:
        print("Could not find end marker in about.html")
else:
    print("Could not find <!-- Founder Card --> in about.html")

if "id=\"founderBioModal\"" not in about_content:
    main_about_end = about_content.find("</main>")
    if main_about_end != -1:
        about_content = about_content[:main_about_end] + "\n" + MODAL_HTML + "\n    " + about_content[main_about_end:]
        print("Inserted founderBioModal into about.html")
    else:
        print("Could not find </main> in about.html")
else:
    print("founderBioModal already present in about.html")

with open(about_path, "w", encoding="utf-8") as f:
    f.write(about_content)

print("All founder updates completed successfully!")
