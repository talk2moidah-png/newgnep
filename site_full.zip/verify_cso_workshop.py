import asyncio
from playwright.async_api import async_playwright
import os

ARTIFACT_DIR = r"C:\Users\SURFACE\.gemini\antigravity\brain\88197918-f7d9-4207-b0c0-288c09f74bfd"
EDGE_PATH = r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"

async def main():
    async with async_playwright() as p:
        browser = await p.chromium.launch(
            executable_path=EDGE_PATH,
            headless=True
        )
        context = await browser.new_context(viewport={'width': 1280, 'height': 850})
        page = await context.new_page()

        # 1. Dedicated Article Page cso-policy-workshop.html
        print("Navigating to cso-policy-workshop.html...")
        await page.goto("http://localhost:8000/cso-policy-workshop.html", wait_until="networkidle")
        await page.wait_for_timeout(1000)
        await page.screenshot(path=os.path.join(ARTIFACT_DIR, "cso-workshop-article-desktop.png"))
        print("Captured cso-workshop-article-desktop.png")

        # 2. Events Page with Card 1 updated
        print("Navigating to events.html...")
        await page.goto("http://localhost:8000/events.html", wait_until="networkidle")
        await page.wait_for_timeout(1000)
        await page.screenshot(path=os.path.join(ARTIFACT_DIR, "cso-workshop-events-card.png"))
        print("Captured cso-workshop-events-card.png")

        # 3. Gallery Page with new items
        print("Navigating to gallery.html...")
        await page.goto("http://localhost:8000/gallery.html", wait_until="networkidle")
        await page.wait_for_timeout(1000)
        await page.screenshot(path=os.path.join(ARTIFACT_DIR, "cso-workshop-gallery-preview.png"))
        print("Captured cso-workshop-gallery-preview.png")

        # 4. Mobile view of article
        print("Testing mobile view of article...")
        mobile_context = await browser.new_context(viewport={'width': 375, 'height': 812})
        mobile_page = await mobile_context.new_page()
        await mobile_page.goto("http://localhost:8000/cso-policy-workshop.html", wait_until="networkidle")
        await mobile_page.wait_for_timeout(1000)
        await mobile_page.screenshot(path=os.path.join(ARTIFACT_DIR, "cso-workshop-article-mobile.png"))
        print("Captured cso-workshop-article-mobile.png")

        await browser.close()
        print("All CSO workshop screenshots captured successfully!")

asyncio.run(main())
