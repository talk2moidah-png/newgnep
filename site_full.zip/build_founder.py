import re
import os

with open(r'C:\Users\SURFACE\.gemini\antigravity\scratch\youth-ngo-website\nature-website-template\founder_bio.txt', 'r', encoding='utf-8') as f:
    text = f.read()

# Parse sections
sections_dict = {}
current_heading = "Biography"
for block in text.split('\n\n'):
    b = block.strip()
    if not b:
        continue
    if b in [
        'FOUNDER', 
        'Biography', 
        'Academic Foundations and Intellectual Development',
        'Professional Experience and Community Engagement',
        'Founding the Global Nature and Environmental Partnership',
        'Research, Publications, and Policy Contributions',
        'Leadership, Service, and Professional Development',
        'Vision for African Climate Governance',
        'Conclusion'
    ]:
        current_heading = b
        sections_dict[current_heading] = []
    else:
        sections_dict.setdefault(current_heading, []).append(b)

print("Parsed sections:")
for k, v in sections_dict.items():
    print(f"  {k}: {len(v)} paragraphs")
