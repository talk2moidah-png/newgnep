import asyncio
from playwright.async_api import async_playwright
import os

ARTIFACT_DIR = r"C:\Users\SURFACE\.gemini\antigravity\brain\88197918-f7d9-4207-b0c0-288c09f74bfd"
EDGE_PATH = r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"

async def main():
    async with async_playwright() as p:
        browser = await p.chromium.launch(
            executable_path=EDGE_PATH,
            headless=True
        )
        context = await browser.new_context(viewport={'width': 1280, 'height': 850})
        page = await context.new_page()

        # 1. Homepage & Founder Card
        print("Navigating to index.html...")
        await page.goto("http://localhost:8000/index.html", wait_until="networkidle")
        await page.wait_for_timeout(1000)

        # Scroll to founder section
        founder_card = page.locator(".founder-card")
        await founder_card.scroll_into_view_if_needed()
        await page.wait_for_timeout(600)
        await page.screenshot(path=os.path.join(ARTIFACT_DIR, "founder-card-index.png"))
        print("Captured founder-card-index.png")

        # 2. Click Founder Card to open modal
        print("Clicking founder card to open modal...")
        await founder_card.click()
        await page.wait_for_selector("#founderBioModal.show", state="visible", timeout=5000)
        await page.wait_for_timeout(800) # wait for animation
        await page.screenshot(path=os.path.join(ARTIFACT_DIR, "founder-modal-overview.png"))
        print("Captured founder-modal-overview.png")

        # 3. Switch to Research & Papers tab
        print("Clicking research tab...")
        await page.click("#bio-research-tab")
        await page.wait_for_timeout(600)
        await page.screenshot(path=os.path.join(ARTIFACT_DIR, "founder-modal-research.png"))
        print("Captured founder-modal-research.png")

        # 4. Standalone page founder.html
        print("Navigating to founder.html...")
        await page.goto("http://localhost:8000/founder.html", wait_until="networkidle")
        await page.wait_for_timeout(800)
        await page.screenshot(path=os.path.join(ARTIFACT_DIR, "founder-standalone-page.png"))
        print("Captured founder-standalone-page.png")

        # 5. Mobile modal test
        print("Testing mobile view...")
        mobile_context = await browser.new_context(viewport={'width': 375, 'height': 812})
        mobile_page = await mobile_context.new_page()
        await mobile_page.goto("http://localhost:8000/index.html", wait_until="networkidle")
        await mobile_page.wait_for_timeout(1000)
        
        mobile_card = mobile_page.locator(".founder-card")
        await mobile_card.scroll_into_view_if_needed()
        await mobile_card.click()
        await mobile_page.wait_for_selector("#founderBioModal.show", state="visible", timeout=5000)
        await mobile_page.wait_for_timeout(800)
        await mobile_page.screenshot(path=os.path.join(ARTIFACT_DIR, "founder-modal-mobile.png"))
        print("Captured founder-modal-mobile.png")

        await browser.close()
        print("All founder screenshots captured successfully!")

asyncio.run(main())
